package com.validate;
import org.springframework.validation.Errors;
import org.springframework.validation.Validator;
public class CustomValidator implements Validator{

	
	public void validate(Object arg0, Errors arg1) {
		
		
		

	
	}	 	  	    	    	     	      	 	

	public boolean supports(Class<?> arg0) {
		// TODO Auto-generated method stub
		return false;
	}
	

}
