package com.controller;
import com.model.*;
import org.springframework.validation.BindingResult;
public class RegistrationController {

	  public String performRegistration( RegistrationBean  registrationBean, 
			BindingResult result) {
		
            	return null;
	
	
	}	 	  		    	    	     	      	 	
}
