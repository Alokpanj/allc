package com.spring.exception;

public class InvalidParcelWeightException extends Exception {
	
	public InvalidParcelWeightException(String msg) {
		
		//fill the code
		
		System.out.println("Invalid Parcel Weight");
	}

}

/*package com.spring.exception;

public class InvalidParcelWeightException extends Exception {
	
	public InvalidParcelWeightException(String msg) {
		
		//fill the code
		super(msg);
	}

}
**/