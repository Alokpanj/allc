package com.spring.bo;

import java.util.Map;

import com.spring.model.Courier;
import com.spring.model.ServiceChargeInfo;

public class CourierBO  {
	
	public double calculateCourierCharge(Courier cObj,String city) {
//   ServiceChargeInfo s=new ServiceChargeInfo();
//	   Courier co=new Courier();
//	   int weight=co.getWeight();
//	   float chargePerKg=co.getChargePerKg();
//	   Map<String,Float> c=s.getLocationServiceCharge();
//	   float ser=s.getLocationServiceCharge().get(city);
		double courierCharge=0.0;
		int weight=cObj.getWeight();
		System.out.println("weight is"+cObj.getWeight());
		//float chargePerKg=cObj.getChargePerKg();
		float ChargePerKg=cObj.getChargePerKg();
		System.out.println("charge per kg  is"+cObj.getChargePerKg());
		System.out.println(cObj);
		Map<String,Float>c=cObj.getServiceCharge().getLocationServiceCharge();
		System.out.println("printing map"+c);
		//float ser=cObj.getServiceCharge().getLocationServiceCharge().get(city);
		//fill the code
		float ser;
		if(c.containsKey(city)){
			ser=c.get(city);
			System.out.println("value printing"+ser);
			
			courierCharge=weight * ChargePerKg;
			courierCharge=courierCharge+ser;
			//System.out.println("courier charge is"+courierCharge);
			return courierCharge;
		}
		else{
			courierCharge=weight * ChargePerKg;
			return courierCharge;
		}
		
	}
	
}
