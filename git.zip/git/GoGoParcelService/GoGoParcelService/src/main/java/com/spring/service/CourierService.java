package com.spring.service;


	import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.spring.bo.CourierBO;
	import com.spring.exception.InvalidParcelWeightException;
	import com.spring.model.Courier;

	public class CourierService {
//		CourierBO bo=new CourierBO();
		Courier c=new Courier();
		private CourierBO cBoObj;

		public CourierBO getcBoObj() {
			return cBoObj;
		}

		public void setcBoObj(CourierBO cBoObj) {
			this.cBoObj = cBoObj;
		}
		
		public double calculateCourierCharge(int courierId,int weight,String city) {
			
			double courierCharge=0.0;
			//fill your code
			if(weight>0 && weight<1000){
				
				//c.setChargePerKg(20.0f);
				ApplicationContext ctx=new ClassPathXmlApplicationContext("beans.xml");
				Courier c=ctx.getBean("c",Courier.class);
				c.setCourierId(courierId);
				c.setWeight(weight);
				System.out.println("c again"+c);
				//c.setServiceCharge(c.getServiceCharge().getLocationServiceCharge(city));
				double d=cBoObj.calculateCourierCharge(c, city);
				return d;
			}
			else{
				try {
					throw new InvalidParcelWeightException("Invalid Parcel Weight");
				} catch (InvalidParcelWeightException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				
			}
			return courierCharge;
		}

	}
	
	/*package com.spring.service;

import com.spring.bo.CourierBO;
import com.spring.exception.InvalidParcelWeightException;
import com.spring.model.Courier;

public class CourierService {
	CourierBO bo=new CourierBO();
	Courier c=new Courier();
	private CourierBO cBoObj;

	public CourierBO getcBoObj() {
		return cBoObj;
	}

	public void setcBoObj(CourierBO cBoObj) {
		this.cBoObj = cBoObj;
	}
	
	public double calculateCourierCharge(int courierId,int weight,String city) {
		
		double courierCharge=0.0;
		//fill your code
		if(weight>0 && weight<1000){
			bo.calculateCourierCharge(c, city);
		}
		else{
			try {
				throw new InvalidParcelWeightException("Invalid Parcel Weight");
			} catch (InvalidParcelWeightException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
		}
		return courierCharge;
	}

}


	
	

**/