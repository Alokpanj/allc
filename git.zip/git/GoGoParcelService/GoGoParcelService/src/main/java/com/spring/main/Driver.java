package com.spring.main;



import java.util.*;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.spring.exception.InvalidParcelWeightException;
import com.spring.model.Courier;
import com.spring.model.ServiceChargeInfo;
import com.spring.service.CourierService;

public class Driver {

	public static void main(String[] args) {
	    
		//fill the code
		Scanner sc=new Scanner(System.in);
		ApplicationContext a=new ClassPathXmlApplicationContext("beans.xml");
		Courier c=(Courier)a.getBean("c"); 
		CourierService cs=(CourierService)a.getBean("courierservice");
		ServiceChargeInfo s=new ServiceChargeInfo();
		System.out.println("Enter the courier ID:");
		int id=sc.nextInt();
		System.out.println("Enter the total weight of parcel:");
		int w=sc.nextInt();
		System.out.println("Enter the city:");
		String city=sc.next();
		c.setCourierId(id);
		c.setWeight(w);
		
		System.out.println("in main"+c);
		System.out.print("Total Courier Charge:"+cs.calculateCourierCharge(c.getCourierId(), c.getWeight(), city));
	}

}
/*package com.spring.main;



import java.util.*;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.spring.exception.InvalidParcelWeightException;
import com.spring.model.Courier;
import com.spring.model.ServiceChargeInfo;
import com.spring.service.CourierService;

public class Driver {

	public static void main(String[] args) {
	    
		//fill the code
		Scanner sc=new Scanner(System.in);
		ApplicationContext a=new ClassPathXmlApplicationContext("beans.xml");
		Courier c=(Courier)a.getBean("c"); 
		CourierService cs=(CourierService)a.getBean("courierservice");
		ServiceChargeInfo s=new ServiceChargeInfo();
		System.out.println("Enter the courier ID:");
		int id=sc.nextInt();
		System.out.println("Enter the total weight of parcel:");
		int w=sc.nextInt();
		System.out.println("Enter the city:");
		String city=sc.next();
		c.setCourierId(id);
		c.setWeight(w);
		
		System.out.println("in main"+c);
		System.out.print("Total Courier Charge:"+cs.calculateCourierCharge(c.getCourierId(), c.getWeight(), city));
	}

}
**/