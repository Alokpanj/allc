package com.bharath.spring.springaop;

public interface ProductService {

	int multiply(int num1,int num2);
}
