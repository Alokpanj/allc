package com.service;

import com.model.Ticket;;

public class TicketService {
	
	
	public double calculateTotalCost(Ticket ticket)
	{
		return 0.0;
		
	}

}
	 	  	    	    	     	      	 	

