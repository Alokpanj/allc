import java.util.Scanner;

public class RegistrationDetails {

	public static void main(String[] args) {
		
		Scanner in = new Scanner(System.in);
		System.out.println("Enter your name:");
		String str1 = in.nextLine();
		
		System.out.println("Enter your age:");
		String str2 = in.nextLine();
		
		System.out.println("Enter your phoneno:");
		String str3 = in.nextLine();
		
		System.out.println("Enter your qualification:");
		String str4 = in.nextLine();
		
		System.out.println("Enter your email id[Please provide valid id, after registering your registration id will be mailed]:");
		String str5 = in.nextLine();
		
		System.out.println("Enter your noofexperience[if any]:");
		String str6 = in.nextLine();
		System.out.print("Dear " +str1+"," );
		
		System.out.println(" Thanks for registering in our portal, registration id will be mailed to "+ str5 + " within 2 working days" );
		

	}

}
