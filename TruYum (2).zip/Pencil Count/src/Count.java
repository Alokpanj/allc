import java.util.*;

public class Count {
                public static int total=1,sum=0 ;
                public static int pencilCount(int x)
                {
                                if(x>1){
                                                total = x * x;
                                                sum +=total;
                                                return pencilCount(x-1);
                                }
                                else 
                                {
                                                sum += 1;
                                }
                                return sum;
                                
                                
                }
                public static void main(String[] args) {
                                Scanner sc = new Scanner(System.in); 
                                int x = 0;
                                System.out.println("Enter the standard:");
                                x= sc.nextInt();
                                if(x>=1 && x<=12){
                                int ans = pencilCount(x);
                                System.out.println("Nila gets "+ans+" pencils");
                                }
                                else {
                                                System.out.println("Invalid Standard");
                                               // System.exit(0);
                                }
                }
}
/*
 * 
 * 
 * 
 * 
 * */
