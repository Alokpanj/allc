package com.student;
import org.springframework.beans.factory.*;
import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.core.io.*;

public class TestClient {
public static void main(String[] args)
{
    Resource res=new ClassPathResource("App.xml");
    @SuppressWarnings("deprecation")
	BeanFactory container=new XmlBeanFactory(res);
    System.out.println("container created");
    Object o=container.getBean("studbean");
    StudentComponent sc=(StudentComponent)o;
    System.out.println(sc.getCity());
    System.out.println(sc.getFname());
    System.out.println(sc.getSname());

}
}