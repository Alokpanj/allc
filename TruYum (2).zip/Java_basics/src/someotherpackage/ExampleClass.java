package someotherpackage;

import Java_basics.MyUtils;

public class ExampleClass {
	
	public static void dosomething(){
		
		MyUtils.printsomejunk1(145);
	}

}
