package Java_basics;

public class ArraysVariables {

	public static void main(String[] args) {

		int [] values = new int[50];
		values[0] = 45; // first index position
		values[9] = 1000;  // last index position
		
		System.out.println(values[0]);
		
		System.out.println(values[9]);
		
		System.out.println(values[5]); // not  inside any value assign then 0 print
		
		//System.out.println(values[50]); // after values[49] exception occur array out of bound 

		
		double [] dvalues = new double[100];
		dvalues[1] = 475; // first index position
		dvalues[3] = 890;  // last index position
		
		System.out.println(dvalues[1]);
		System.out.println(dvalues[3]);
		
		
		String [] str = new String [] {"My","Name","is"};
		System.out.println(str[1]);
		
		str = new String[20];
		System.out.println(str[2]); // null value assign 
		
		
		String [] str1 = new String [3]; 
		str1[0]="My";
		str1[1]="Name";
		str1[2]="is";
				
		System.out.println(str1[2]);
		
		
	}

}
