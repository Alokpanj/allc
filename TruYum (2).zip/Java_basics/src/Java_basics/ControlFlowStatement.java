package Java_basics;

public class ControlFlowStatement {

	public static void main(String[] args) {

		boolean hungry = true;
		
		if(hungry){     //if(hungry==true){    // if(2 == 2 ){  
			System.out.println("I'm starving");
		}
		
		else{
         System.out.println("I'm not hungry");
		}
		
		
         int hr = 5;
         
         if(hr < 6){
        	System.out.println("Not Hungry"); 
        	 
         }
         else{
        	System.out.println("Hungry"); 
         }
         
          
         
         int favoriteTemp = 75;
         int CurrentTemp = 60;
         String opinion;
         
         if(CurrentTemp == favoriteTemp){
         
         if(CurrentTemp < favoriteTemp - 30){
        	 opinion ="Its Pretty Darn Cold"; 
         }else if(CurrentTemp < favoriteTemp -20 ){
        	 opinion ="Its kinda cold out...";
         }
          else if(CurrentTemp > favoriteTemp + 10){
        	  opinion ="Its too hot..";
         }
          else {
        	  opinion ="Its Beautiful day...";
          }
         
         }
         else{
        	 opinion ="Unknown Temp...";
         }
         System.out.println(opinion);
         
         
         int month =6;
         String monthString;
         
         switch(month){
         
         case  1 : monthString = "January";
             break;
             
         case  2 : monthString = "February";
         break;
         
         case  3 : monthString = "March";
         break;
         
         case  4 : monthString = "April";
         break;
         
         default: monthString = "Unknown Month";
         break;
         }
         System.out.println(monthString);
		}  

}
