package Java_basics;

public class MyUtils {

	public static void printsomejunk(String args){
		System.out.println("my name is alok. " + args);
	}
	
	public static String printsome(String args){
		return args;	
	}

	
	public static void printsomejunk1(int args){
		System.out.println("Integer Method value: " + args);
		
	}
	
	public static void Sum2Numbers(int args1, int args2){
		System.out.println(args1 + args2);
	}
	
	public static int Add10(int SomeArgs){
		int result = SomeArgs+10;
		return result;
	}
	
}
