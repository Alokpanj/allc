package Java_basics;

import someotherpackage.ExampleClass;

public class MethodInJava1 {

	public static void main(String[] args) {

		System.out.println("Cognizant");
		MyUtils.printsomejunk("I am From Bhopal.");
		
		System.out.println(MyUtils.printsome("Hello.."));
		
		//MyUtils.printsomejunk1(45);
		
		System.out.print("Sum : ");
		MyUtils.Sum2Numbers(20,30);
		
		//int myvar = MyUtils.Add10(99)+1-23*2;
		//System.out.println(myvar);
		
		ExampleClass.dosomething();
		/*  without static Add10() method
		//MyUtils.Add10(100);
		MyUtils myVar;
		myVar = new MyUtils();
		MyUtils.printsomejunk("5656");
		
		myVar.Add10(23);
	
		*/
		
	}
	
	

}
