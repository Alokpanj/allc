package Java_basics;

public class VaraiablesContinued {

	public static void main(String[] args) {
		
		
		int i = 1000;
		
		System.out.println(i);
		
		
		long l = 84588l;
		
		System.out.println(l);
		
		
		short s = 32767;
		
		System.out.println(s);
		
		
		byte b = 127;
		
		System.out.println(b);
		
		
		double dec = 233.255;
		
		System.out.println(dec);
		
		boolean st = false;
		
		System.out.println(st);
		
		
		char c = '3';
		System.out.println(c);

	}

}
