package Java_basics;

public class Variables {

	public static void main(String[] args) {

		int x;
		x = 40;
		
		System.out.println("Integer Value : "+x);
		
		System.out.println(x+7);
		
		System.out.println(x-7);
		
		System.out.println(x/7);
		
		System.out.println(x*7);
		
		
		
		float f;
		
		f =23;
		
		
		System.out.println("Float Value : "+f);
		
		System.out.println(f+7);
		
		System.out.println(f-7);
		
		System.out.println(f/7);
		
		System.out.println(f*7);
		
		String str;
		
		str="Alok";
		
		System.out.println("String Value : "+str);
		
	}

}
