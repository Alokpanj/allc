package Java_basics;

public class MethodsInJava {

	public static void main(String[] args) {

		System.out.println("Cognizant");
		printsomejunks("I am From Bhopal.");
		printsomejunk_1(45);
		
	}
	
	public static void printsomejunks(String args){
		System.out.println("my name is alok. " + args);
	}

	
	public static void printsomejunk_1(int args){
		System.out.println("Integer Method value: " + args);
	}
}
