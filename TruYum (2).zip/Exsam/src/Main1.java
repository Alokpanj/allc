
public class Main1 {

	public static void main(String[] args) {
		private int cityPincode;
		private String cityName;
		private double averageAnnualRainfall;
			 
		 
	}

}
/*

private int cityPincode;
private String cityName;
private double averageAnnualRainfall;