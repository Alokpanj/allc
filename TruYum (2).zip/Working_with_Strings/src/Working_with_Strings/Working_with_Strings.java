package Working_with_Strings;

public class Working_with_Strings {

	public static void main(String[] args) {

		String str = "ROBERT";
		System.out.println(str);
		System.out.println("string Length str : "+ str.length()+"\n"); // length of string
		 
	
		String str1 = "ABCDEF";
		System.out.println("string Length str1: "+ str1);
		String extractedString = str1.substring(2); // escapce the index vale from 2 output- CDEF
		System.out.println(extractedString); 
		System.out.println("B/w the range : "+str1.substring(0,3));
	
		
		String a = "hello";
		String b = "there";
		
		if(a == "hello"){
			System.out.println("1st...");
			// this is a trap. don't do this
		}
		
		if(a.equals("hello")){
			System.out.println(a); // hello
			//System.out.println("2nd.. : " +a+" "+b);	// use this!!
			
			}
		// for Ignore the upper and lower case string then
		if(b.equalsIgnoreCase("There"))
		//if(b.equals("there"))
		{
			System.out.println("Printed there");
			
		}
		
		
		String s = "Alok Panjiyar";
		
		
		System.out.println("String chatAt : "+s.charAt(6));
		
		
		
		String st = "I am Alok kumar Alok";
		int c = st.indexOf("Alok");
		int d = st.indexOf("Alok" , 7);
		
		System.out.println(c);
		System.out.println(d);
		
		String s1 = "lake and lake are Ocean";
		
		int e = s1.lastIndexOf("lake",0);
		System.out.println(e);
	
	}

}
