package OOPS;

public class Bird {
	
	public void fly(){
		
		System.out.println("Bird Flying....");
		
	}

}
