package OOPS;

public class Human1 {
	String name;
	int age;
	int heightInInches;
	String eyeColor;
	
	public  Human1(){
		
		name = "Alok Panjiyar";
		age = 21;
		heightInInches = 72 ;
		eyeColor ="Brown";	
		
		
	}
	
  
	 public Human1(String name, int age, int heightInInches, String eyeColor) {
		super();
		this.name = name;
		this.age = age;
		this.heightInInches = heightInInches;
		this.eyeColor = eyeColor;
	}


	public void speak(){
		 
		 System.out.println("Hello...\n"+"my name is " + name);
		 System.out.println("I am "+age+" years old");
		 System.out.println("I am "+heightInInches+ " inches tall");
		 System.out.println("My eye color is "+eyeColor+"\n");
		 
	 }
	
	public void eat(){
		
	System.out.println("Eating...");	
		
	}
	
	
	public void walk(){
		
		System.out.println("Walking...");
		
	}


	public void work(){
		
		System.out.println("Working....");
	
    }
	 
	 
}
