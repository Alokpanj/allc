package OOPS;

public class Zoo {

	public static void main(String[] args) {
		
		Animals animals1 = new Animals("Dog", "Male", 10, 80);
		Animals animals2 = new Animals("Cat", "Female", 3, 25);
		Animals animals3 = new Animals("Cow", "Female", 12, 800);
		

	 animals1.ani();
	 animals2.ani();
	 animals3.ani();
	 
	 
	 //animals1.eat();
	 //animals1.sleep();
	 
	 Fish fish1 = new Fish();
	 fish1.swim();
	 
	 
	 Bird bird1 = new Bird(); 
	 bird1.fly();
	 
	 
	 
	}

}
