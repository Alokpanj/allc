package OOPS;

public class Human {
	String name;
	int age;
	int heightInInches;
	String eyeColor;
	
	public Human(){
		
		
	}
	
  
	 public void speak(){
		 
		 System.out.println("Hello...\n"+"my name is " + name);
		 System.out.println("I am "+age+" years old");
		 System.out.println("I am "+heightInInches+ " inches tall");
		 System.out.println("My eye color is "+eyeColor+"\n");
		 
	 }
	
	public void eat(){
		
	System.out.println("Eating...");	
		
	}
	
	
	public void walk(){
		
		System.out.println("Walking...");
		
	}


	public void work(){
		
		System.out.println("Working....");
	
    }
	 
	 
}
