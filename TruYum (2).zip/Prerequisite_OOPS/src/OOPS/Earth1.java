package OOPS;

public class Earth1 {

	public static void main(String[] args) {
		
		Human1 human1 = new Human1("ALOK",21,72,"Brown");
		Human1 human2 = new Human1("Panjiyar",22,70,"Blue");
		Human1 human3 = new Human1("Ravi",20,71,"Black");
		
		human1.speak();
		human2.speak();
		human3.speak();

	}

}
