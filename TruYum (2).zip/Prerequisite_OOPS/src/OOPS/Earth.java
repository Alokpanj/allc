package OOPS;

public class Earth {
	
	public static void main(String [] args){
		
		Human alok;
		alok = new Human();
		
		
		
		alok.name = "Alok Panjiyar";
		alok.age = 21;
		alok.heightInInches = 72 ;
		alok.eyeColor ="Brown";	
		
		alok.speak();
		
		
		
		Human aman;
		
		aman = new Human();
		
		
		
		aman.name = "Aman";
		aman.age = 22;
		aman.heightInInches = 68 ;
		aman.eyeColor ="Black";	
		
		aman.speak();
		
	}

}
