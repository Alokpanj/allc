package OOPS;

public class Fish {
	
	public void swim(){
	System.out.println("Fish Swiming.....\n");
	}

}
