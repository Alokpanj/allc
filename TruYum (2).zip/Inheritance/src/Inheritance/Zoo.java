package Inheritance;

public class Zoo {

	public static void main(String[] args) {
		
		System.out.println("Animals : \n");
		
		
		Animals animals1 = new Animals("Dog", "Male", 10, 80);
		animals1.ani();
		
		//Animals animals2 = new Animals("Cat", "Female", 3, 25);
		//Animals animals3 = new Animals("Cow", "Female", 12, 800);
		//animals2.ani();
		//animals3.ani();
	 
	    animals1.eat();
	    animals1.sleep(); 
	 
	    
	    Fish fish1 = new Fish("whale", "Female", 12, 7000);
	    fish1.fishs();
	 
	    fish1.swim();
	    fish1.eat();
	    fish1.sleep();
	    // fish1.fly(); cannot call this type fly() is in bird class
	 
	 
	 
	 
	 
		 Bird bird1 = new Bird("peacock", "Female", 5, 80); 
		 bird1.birds();
		 
		 bird1.fly();
		 bird1.eat();
		 bird1.sleep();
	 
	
	 
	 
	 
	}

}
