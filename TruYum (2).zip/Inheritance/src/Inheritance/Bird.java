package Inheritance;

public class Bird extends Animals{
	
	
	public Bird(String name, String gender, int age, int weightInLbs) {
		super(name, gender, age, weightInLbs);
		
	}
	

	public void birds(){
		 
		 System.out.println("Name : "+name);
		 System.out.println("Gender : "+gender);
		 System.out.println("age : "+age);
		 System.out.println("Weight : "+weightInLbs+"\n");
		 
	 }

	public void fly(){
		
		System.out.println("Bird Flying....");
		
	}

}
