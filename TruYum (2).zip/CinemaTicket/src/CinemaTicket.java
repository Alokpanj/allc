import java.util.Scanner;

class CinemaTicket {

	public static String roundToTwoPlaces(float val) {
		return String.format("%.2f", val);
	}

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the no of ticket:");
		int numOfTickets = sc.nextInt();
		
		

		if (numOfTickets >= 5 && numOfTickets <= 40) {
			System.out.println("Do you want refreshment:");
			char refresh = sc.next().charAt(0);
			System.out.println("Do you have coupon code:");
			char cc = sc.next().charAt(0);
			System.out.println("Enter the circle:");
			char circle = sc.next().charAt(0);

			float total = 0f, totalCost = 0f, discount1 = 0f, discount2 = 0f;
			if (circle == 'k' || circle == 'q') {

				if (circle == 'k') {
					total = numOfTickets * 75;
					totalCost = total;
				}
				if (circle == 'q') {
					total = numOfTickets * 150;
					totalCost = total;
				}

				if (numOfTickets > 20) {
					discount1 = discount1 + (float) (0.10 * total);
					totalCost = totalCost - discount1;
				}
				if (cc == 'y') {
					discount2 = discount2 + (float) (0.02 * totalCost);
					totalCost = totalCost - discount2;
				}
				if (refresh == 'y') {
					totalCost = numOfTickets * 50 + totalCost;
				}
				System.out.println("Ticket cost:" + CinemaTicket.roundToTwoPlaces(totalCost));
			}

			else {
				System.out.println("Invalid Input");
			}
		}

		else {
			System.out.println("Minimum of 5 and Maximum of 40 Tickets");
		}
		
	}
}
