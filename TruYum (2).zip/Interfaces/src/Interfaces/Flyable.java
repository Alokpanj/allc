package Interfaces;

public interface Flyable {
	
	// abstract method
	public void fly();

}
