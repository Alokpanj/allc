let name='alok';
console.log(name);

let last='kumar';
console.log(last);

let firstname ='aman';
let lastname ='kumar';