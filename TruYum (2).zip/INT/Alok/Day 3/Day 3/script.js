<script>
		
		function displayRadioValue() { 
                	var ele = document.getElementsByName('rb'); 
               		var check = false;
            		for(var i = 0; i < ele.length; i++) { 
                		if(ele[i].checked) 
                		check = true;
			}
			return check;
             
        	}

		
		 
		
		function hasNumbers(input) {
    			return /[0-9]/.test(input);
		}
		function hasSymbols(input) {
    			return /[!@#$%^&*()_+\-=\[\]{};':"\\|,.<>\/?]/.test(input);
		}
		
		document.getElementById("submit").onclick = function(){
		var isNameCorrect = true;
		var isPasswordCorrect = true;
		var isAddressCorrect = true;

		var array = []
		var checkboxes = document.querySelectorAll('input[type=checkbox]:checked')

		for (var i = 0; i < checkboxes.length; i++) {
  			array.push(checkboxes[i].value)
		}
			
			
			var isCheck;

			if(array.length == 0)
				isCheck = false;
			else
				isCheck = true;

			var isRadioSelected = displayRadioValue();
			if(document.getElementById("name").value == ""){
				alert("Name cannot be empty");
				isNameCorrect = false;
			}

			if(hasNumbers(document.getElementById("name").value)){
				alert("Name cannot have numbers");
				isNameCorrect = false;
			}
			if(hasSymbols(document.getElementById("name").value)){
				alert("Name cannot have special symbols");
				isNameCorrect = false;
			}
			if(document.getElementById("name").value.length <2 || document.getElementById("name").value.length >30 ){
				alert("Name length should be between 2 to 30 characters");
				isNameCorrect = false;
			}

			if(document.getElementById("address").value == ""){
				isAddressCorrect = false;
			}
			
			if(!isRadioSelected){ alert("Gender field cannot be empty"); }
			
			if(!isAddressCorrect){ alert("Address field cannot be empty"); }

			if(!isCheck){ alert("Skills field cannot be empty"); }

			if(document.getElementById("password").value == ""){
				alert("Password cannot be empty");
				isPasswordCorrect = false;
			}
			
			
			
			if(isNameCorrect && isRadioSelected && isCheck && isAddressCorrect && isPasswordCorrect){
				alert("Details submitted successfully");
			}
		}

</script>