<script language ="javscript">
    functionx(){
    
    var qpt="1";
    var pattern = /first/g;
    document.write(qpt.match(pattern)[1]);
    
}
</script>