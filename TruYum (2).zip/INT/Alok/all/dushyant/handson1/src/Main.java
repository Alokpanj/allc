import java.util.Scanner;

public class Main {

	public static void main(String []args){
		
		Scanner sc = new Scanner(System.in);
		
		int inp = sc.nextInt();
		
		int[] arr = new int[inp]; 
		String[] s = new String[inp];
		int res = 0;
		
		for(int i=0;i<inp;i++)
		{
			s[i] = sc.next();
			int ip = sc.nextInt();
			int iq = sc.nextInt();
		
			
			res = (ip*iq)/100;
			arr[i] = res;
		}
		
		int min = arr[0]; 
		
		for(int i=0;i<inp-1;i++){
			if(arr[i]>arr[i+1])
			   min = arr[i+1];
		}
		
		
		for(int i=0;i<inp;i++){
			if(arr[i]==min)
			{
				System.out.println(s[i]);
			}
		}
		
		
		sc.close();
	}
}
