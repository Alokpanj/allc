package practice.dao;

public interface cartdao {

}
