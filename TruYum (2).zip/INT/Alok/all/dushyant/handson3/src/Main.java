
public class Main {

	public static void main(String[] args) {
		Shape sp1 = new Rectangle();
		Shape sp2 = new Triangle();
		Shape sp3 = new Cube();
		Shape sp4 = new Sphere();
		
		int shape[] = new int[5];
		
	}

}
