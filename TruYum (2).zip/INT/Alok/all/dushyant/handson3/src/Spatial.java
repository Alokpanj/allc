public interface Spatial {

}
