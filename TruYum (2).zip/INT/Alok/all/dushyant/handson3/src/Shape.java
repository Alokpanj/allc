
public abstract class Shape {

}
