use truYum_Db;

insert into menu_item values(1, 'Sandwich', 99, 'Yes', '2017/03/15', 'Main Course', 'Yes');
insert into menu_item values(2, 'Burger', 129, 'Yes', '2017/12/23', 'Main Course', 'No');
insert into menu_item values(3, 'Pizza', 149, 'Yes', '2017/08/21', 'Main Course', 'No');
insert into menu_item values(4, 'French Fries', 57, 'No', '2017/07/02', 'Starters', 'Yes');
insert into menu_item values(5, 'Chocolate Brownie', 32, 'Yes', '2022/11/02', 'Dessert', 'Yes');

Select * from menu_item;

select * from menu_item where me_date_of_launch <= curdate() and me_active = 'Yes';

select * from menu_item where me_id = 3;

update menu_item
set me_name = 'Chilli Patato', me_price = 200 where me_id = 4;

insert into user values(1, 'Remo Dsouza');
insert into user values(2, 'Salman Yousuf');



insert into cart values(1,1,1);
insert into cart values(2,1,2);
insert into cart values(3,1,3);

select menu_item.me_name, menu_item.me_price, menu_item.me_category, menu_item.me_free_delivery from menu_item
inner join cart on menu_item.me_id = cart.ct_pr_id;

select menu_item.me_name, menu_item.me_price, menu_item.me_category, menu_item.me_free_delivery from menu_item
inner join cart on menu_item.me_id = cart.ct_pr_id
where cart.ct_us_id = 1;

select sum(menu_item.me_price)Total from menu_item
inner join cart on menu_item.me_id = cart.ct_pr_id
where cart.ct_us_id = 1;


delete from cart where ct_us_id = 1 and ct_pr_id = 3;

