create database truYum_Db;

use truYum_Db;

create table user(us_id int primary key, us_name varchar(60));
create table menu_item(me_id int primary key, me_name varchar(100), me_price numeric(8,2), me_active varchar(3), me_date_of_launch date, me_category varchar(45), me_free_delivery varchar(3));


CREATE TABLE `cart` (
  `ct_id` int(11) NOT NULL auto_increment,
  `ct_us_id` int(11) NOT NULL,
  `ct_pr_id` int(11) NOT NULL,
  PRIMARY KEY (`ct_id`),
  KEY `ct_us_id_idx` (`ct_us_id`),
  KEY `ct_pr_id_idx` (`ct_pr_id`),
  CONSTRAINT `ct_pr_id` FOREIGN KEY (`ct_pr_id`) REFERENCES `menu_item` (`me_id`),
  CONSTRAINT `ct_us_id` FOREIGN KEY (`ct_us_id`) REFERENCES `user` (`us_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
 