package WhileLoop;

public class LoopPractice {

	public static void main(String[] args) {

		//Q1
		
		/*
		while(true){
         System.out.println("Alok");	// infinnite Looop
         */
		
		/* 
		  while( test)  {
		
		 Body
		 
	  }  
	    
	   */
         
		//Q2
		
         int count = 0;
         while(count<=10){
             System.out.println("Alok : ");  // 10 Times print
            count = count +1;
         }
             
       //Q2
             int count1 = 0;
             while(count1<=15){
                 System.out.println("Panjiyar : " + count1);  // 15 Times print with Number
                 count1 = count1 +1;
                 
                 if(count1 == 5){  // break statement run 5 times
                	 break;
                 }
		}
             
             
            
	}

}
