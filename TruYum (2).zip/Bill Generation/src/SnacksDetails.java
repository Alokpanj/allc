import java.util.Scanner;

public class SnacksDetails {

	

	

	public static void main(String[] args) {

		
		Scanner	s = new Scanner(System.in);
		
		System.out.println("Enter the no of pizzas bought:");
		int n1 =  s.nextInt();
		
		System.out.println("Enter the no of puffs bought:");
		int n2 = s.nextInt();
		
		System.out.println("Enter the no of cool drinks bought:");
		int n3 = s.nextInt();
		
		int Total = n1*100+n2*20+n3*10;
		
		System.out.println("Bill Details");
		
		System.out.println("No of pizzas:"+n1);
		System.out.println("No of puffs:"+n2);
		System.out.println("No of cooldrinks:"+n3);
		System.out.println("Total price="  +Total);
		System.out.println("ENJOY THE SHOW!!!");
		

	}

}















































//System.out.println("No of pizzas:");
//System.out.println("No of puffs:");
//System.out.println("No of cooldrinks:"+n3);
//System.out.println("Total price="  +sum);
//System.out.println("ENJOY THE SHOW!!!");


//System.out.print("Enter the no of cool drinks bought:");
//int n3 = s.nextInt();