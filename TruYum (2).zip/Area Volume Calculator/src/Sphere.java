public class Sphere extends Shape implements Spatial 
{
    private double radius;
    
    public double getRadius()
    {
        return radius;
    }
    
    public void setRadius(double r)
    {
        this.radius=r;
    }
    
    public double area()
    {
        return (4*Math.PI*this.radius*this.radius);
    }
    
    public double volume()
    {
        double radsphere =this.radius;
        return (4*Math.PI*radsphere*radsphere*radsphere)/3;
    }
}