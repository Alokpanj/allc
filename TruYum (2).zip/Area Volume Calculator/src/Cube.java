public class Cube extends Shape implements Spatial
{
    private double length;
    private double width;
    private double height;
    
    public double getLength()
    {
        return length;
    }
    
    public void setLength(double l)
    {
        this.length=l;
    }
    
    public double getWidth()
    {
        return width;
    }
    
    public void setWidth(double w)
    {
        this.width=w;
    }
    
    public double getHeight()
    {
        return height;
    }
    
    public void setHeight(double h)
    {
        this.height=h;
    }
    
    public double area()
    {
        double l,w,h,areacube;
        l=this.length;
        w=this.width;
        h=this.height;
        areacube=((2*l*w)+(2*l*h)+(2*w*h));
        return areacube;
    }
    
    public double volume()
    {
        return (this.length*this.width*this.height);
    }
    
    
    
    
}