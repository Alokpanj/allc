public interface Spatial
{

}