public class Triangle extends Shape
{
 private double base;
 private double height;
 
 public double getBase()
 {
     return base;
 }
 public void setBase(double b)
 {
     this.base=b;
 }
 public double getHeight()
 {
     return height;
 }
 public void setHeight(double h)
 { 
     this.height=h;  
 }
 public double area()
 {
     return ((this.base*this.height)/2);
 }
 public double volume()
 {
     return -1;
 }
 
}