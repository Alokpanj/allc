import java.util.*;
public class Main
{
    public static void main(String args[])
    {
        Scanner sc=new Scanner(System.in);
        Shape[] arr=new Shape[5];
        for(int i=0;i<5;i++)
        {
            
            String str= sc.next();
            if(str.equalsIgnoreCase("Triangle"))
            {
                Triangle triangle=new Triangle();
                triangle.setBase(sc.nextDouble());
                triangle.setHeight(sc.nextDouble());
                System.out.println("Area "+triangle.area());
            }
            else if(str.equalsIgnoreCase("Rectangle"))
            {
                Rectangle rectangle=new Rectangle();
                rectangle.setLength(sc.nextDouble());
                rectangle.setWidth(sc.nextDouble());
                System.out.println("Area "+rectangle.area());
            }
            else if(str.equalsIgnoreCase("Sphere"))
            {
                Sphere sphere =new Sphere();
                sphere.setRadius(sc.nextDouble());
                System.out.println("Area "+sphere.area());
                System.out.println("Volume "+sphere.volume());
                
            }
            else if(str.equalsIgnoreCase("Cube"))
            {
                Cube cube=new Cube();
                cube.setLength(sc.nextDouble());
                cube.setWidth(sc.nextDouble());
                cube.setHeight(sc.nextDouble());
                System.out.println("Area "+cube.area());
                System.out.println("Volume "+cube.volume());
            }
        }
        
    }
}