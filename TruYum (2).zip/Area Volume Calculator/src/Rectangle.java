public class Rectangle extends Shape
{
   private double length;
   
   private double width;
   
   public double getLength()
   {
       return length;
   }
   
   public void setLength(double l)
   {
        this.length=l;
   }
   
   public double getWidth()
   {
       return width;
   }
   public void setWidth(double w)
   {
        this.width=w;
   }
   
   public double area()
   {
       return (this.length*this.width);
   }
   public double volume()
   {
       return -1;
   }
   
   
}