import java.awt.List;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Scanner;

public class UniqueChar {


		 
			 
			 public static void main(String[] args) throws ParseException {
				    Scanner sc = new Scanner(System.in);
				    System.out.println("Enter the sentence:");
				    String s1 = sc.nextLine();
				    StringBuffer sb = new StringBuffer(s1);
				    for (int i = 0; i < sb.length(); i++) {
				      int count = 0;
				      for (int j = i + 1; j < sb.length(); j++) {
				        if (sb.charAt(i) == sb.charAt(j)) {
				         sb.deleteCharAt(j);
				          j--;
				          count++;
				        }
				      }
				      if (count >= 1) {
				        sb.deleteCharAt(i);
				    	 
				        i--;
				      }
				    }
				    int i=0;
					System.out.println("Unique characters:\n"+sb.length());
					
			 
			 }

}
