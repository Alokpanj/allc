import java.util.Scanner;

public class AsciValue {

	public static void main(String[] args) {

		Scanner in = new Scanner(System.in);
		System.out.println("Enter the digits:");
		int n1 = in.nextInt();
		int n2 = in.nextInt();
		int n3 = in.nextInt();
		int n4 = in.nextInt();
		
		
		
		
		System.out.println(n1+"-");
		System.out.println(n2+"-");
		System.out.println(n3+"-");
		System.out.println(n4+"-");

	
	}
}

/**
 * 
 * 
 * char c;
		for(int i=65; i<=128;i++){
			c=(char)i;
			System.out.println(str1+"-"+c);
 * 
 */