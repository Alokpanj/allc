
public class Y {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		 int[] myArray = {1,2,3,4,5};
		 X.doIt(myArray);
		 for(int j=0; j<myArray.length; j++){
			 System.out.println(myArray[j]+" ");
		 }
		 
		 
		  
	}

}
