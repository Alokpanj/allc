 
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Set;
import java.util.TreeSet;

 


 

 public class P1 {
	
	
	public static void main(String[] args) {
		String str="";
		System.out.println(" "+str);
	}
	
	
	
	
	
}
 
 

	 
 
	
 

 
	
	
	
 
