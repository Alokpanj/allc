import java.text.CollationElementIterator;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.Set;
import java.util.SortedMap;
import java.util.TreeMap;

public class Z {

 
	 
 
 
 public static void main(String[] args) {
	 
	 
	 TreeMap<Integer, String> hm = new  TreeMap<Integer, String>();
	 hm.put(2, "Two");
	 hm.put(4, "four");
	 hm.put(1, "one");
	 hm.put(6, "Two22");
	 hm.put(7, "Two44");
	 
	 SortedMap<Integer, String> sm = hm.subMap(2, 7);
	 SortedMap<Integer, String> sm2 = hm.tailMap(4);
	 
	 System.out.println(sm2);
 }
 
 
}