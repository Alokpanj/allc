import java.sql.*;

public class FlightManagementSystem{
    public int i;
    public boolean addFlight(Flight obj){
        try{
        Connection con=DB.getConnection();
        PreparedStatement ps = con.prepareStatement("insert into flight values(?,?,?,?,?)");
        ps.setInt(1,obj.getFlightId());
        ps.setString(2,obj.getSource());
        ps.setString(3,obj.getDestination());
        ps.setInt(4,obj.getNoOfSeats());
        ps.setDouble(5,obj.getFlightFare());
        i = ps.executeUpdate();
        
        }
        catch(Exception e){
            System.out.println(e);
            
        }
        if(i ==0) {return false;}
        
        else {return true;}
    }
    
}