package com.cognizant.truyum.dao;

public final class MenuItemDaoCollectionImplTest {

	public static void main(String[] args) {

 
		//body
		


	}
	
	
	public static void testGetMenuItemListAdmin() {
		
	} 
	
	public static void testGetMenuItemListCustomer() {
		
	} 
	
	public static void testModifyMenuItem() {
		
	}
	
	public static void testGetMenuItem() {
		
	} 

}
