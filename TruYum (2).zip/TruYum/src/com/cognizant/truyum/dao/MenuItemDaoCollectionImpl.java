package com.cognizant.truyum.dao;

import java.util.ArrayList;
import java.util.List;

import com.cognizant.truyum.model.MenuItem;
import com.cognizant.truyum.util.DateUtil;

	public class MenuItemDaoCollectionImpl implements MenuItemDao {
	
	//private static List<MenuItem> menuItemList= new ArrayList<>();{

   

	
	
	
    // MenuItem m1 = new MenuItem(1l, "Sandwich", 99.00f, true, DateUtil.convertToDate("15/03/2017"), "Main course",
        //    true);
    // MenuItem m2 = new MenuItem(2l, "Burger", 129.00f, true, DateUtil.convertToDate("23/12/2017"), "Main course",
        //   false);
   //  MenuItem m3 = new MenuItem(3l, "Pizza", 149.00f, true, DateUtil.convertToDate("21/08/2018"), "Main course",
        //   false);
  //   MenuItem m4 = new MenuItem(4l, "French Fries", 57.00f, false, DateUtil.convertToDate("02/07/2017"), "Starters",
        //   true);
  //   MenuItem m5 = new MenuItem(5l, "chocolate Brownie", 32.00f, true, DateUtil.convertToDate("02/11/2022"),
         //  "Desserts", true);

  ///	menuItemList.add(m1);
  // 	menuItemList.add(m2);
  // 	menuItemList.add(m3);
  // 	menuItemList.add(m4);
 //  	menuItemList.add(m5);


	//}
	
	
	
	
	
	public MenuItemDaoCollectionImpl(){
		
	}
	

	@Override
	public List<MenuItem> getMenuItemListAdmin() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<MenuItem> getMenuItemListCustomer() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void modifyMenuItem(MenuItem menuItem) {
		// TODO Auto-generated method stub

	}

	@Override
	public MenuItem getMenuItem(long menuItemId) {
		// TODO Auto-generated method stub
		return null;
	}

}
