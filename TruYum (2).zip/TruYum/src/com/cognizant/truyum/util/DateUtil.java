package com.cognizant.truyum.util;

//import java.sql.Date;
import java.util.Date;
import java.text.ParseException;
import java.text.SimpleDateFormat;

public class DateUtil {

	public static Date convertToDate(String date){
		Date d=null;
		try {
		SimpleDateFormat s_d_f = new SimpleDateFormat("dd/MM/yyyy");
		 d =  (Date) s_d_f.parse(date);
		}
		
		
		catch(ParseException p){
			System.out.println("Invalid format");
		}
		
		
		return d;
	}

		
		
		
	}
