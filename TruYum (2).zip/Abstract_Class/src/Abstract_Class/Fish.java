package Abstract_Class;

public class Fish extends Animals{
	
	
	
	public Fish(String name, String gender, int age, int weightInLbs) {
		super(name, gender, age, weightInLbs);
		
	}
	
	public void fishs(){
		 
		 System.out.println("Name : "+name);
		 System.out.println("Gender : "+gender);
		 System.out.println("age : "+age);
		 System.out.println("Weight : "+weightInLbs);
		 
	 }

	public void swim(){
	System.out.println("Fish Swiming.....");
	}

	
	public void move() {
		System.out.println("fish is swimming.....\n");
		
	}

}
