package Abstract_Class;

public class Sparrow extends Bird implements Flyable{

	public Sparrow(String name, String gender, int age, int weightInLbs) {
		super(name, gender, age, weightInLbs);
		
		
	}

	public void sparrows(){
		 
		 System.out.println("Name : "+name);
		 System.out.println("Gender : "+gender);
		 System.out.println("age : "+age);
		 System.out.println("Weight : "+weightInLbs);
		 
	 }
	
	public void fly() {
		System.out.println("Sparrow Fly  to High....");
		
	}
	
}
