package Abstract_Class;

public class Chicken extends Bird{

	public Chicken(String name, String gender, int age, int weightInLbs) {
		super(name, gender, age, weightInLbs);
		
	}
	
	public void chickens(){
		 
		 System.out.println("Name : "+name);
		 System.out.println("Gender : "+gender);
		 System.out.println("age : "+age);
		 System.out.println("Weight : "+weightInLbs);
		 
	 }
	
	
		// overriding the method define in Bird.
	   // Override = Replace
	/*	
	public void fly(){
		System.out.println("Not able to fly...");

		
	}
	*/

}
