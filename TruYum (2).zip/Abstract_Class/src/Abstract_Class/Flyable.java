package Abstract_Class;

public interface Flyable {
	
	// abstract method
	public void fly();

}
