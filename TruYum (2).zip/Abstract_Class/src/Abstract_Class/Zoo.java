package Abstract_Class;

public class Zoo {

	public static void main(String[] args) {
		
		System.out.println("Animals : \n");
		
		
		//Animals animals1 = new Animals("Dog", "Male", 10, 80);
		//animals1.ani();
		
	   // animals1.eat();
	   // animals1.sleep(); 
	 
	    
	    Fish fish1 = new Fish("whale", "Female", 12, 7000);
	    fish1.fishs();
	 
	    fish1.swim();
	    fish1.eat();
	    fish1.sleep();
	    //fish1.move();
	  
	  // OR  this type  also written
	    
	    Animals fish2 = new Fish("SHARK", "Female", 6, 700);
	    fish2.fishs();
	 
	    fish2.swim();
	    fish2.eat();
	    fish2.sleep();
	    fish2.move();
	 
	 
		 Bird bird1 = new Bird("peacock", "Female", 5, 80); 
		 bird1.birds();
		 
		
		 bird1.eat();
		 bird1.sleep();
	 
	
	     Chicken chicken1 = new Chicken("Chicken", "Female", 5, 80);
	     chicken1.chickens();
	     

	     chicken1.eat();
	     chicken1.sleep();
	     
	     
	      
	     Sparrow sparrow1 = new Sparrow("Sparrow", "Male", 2, 8);
	     sparrow1.sparrows();
	     
	     sparrow1.fly();
	     //sparrow1.move();
	 
	      // OR This Type
	     
	     Animals sparrow2 = new Sparrow("Bird", "Female", 1, 2);
	     sparrow2.sparrows();
	     sparrow2.move();
	     
	     
	     moveAnimals(fish1);  // polymorphims
	     moveAnimals(sparrow1);
	     
	     
	}
	     public static void moveAnimals(Animals animals){
	     animals.move();
	     
	     
	     Flyable flyingBird = new Sparrow("crow" , "M", 2, 2);
	     //System.out.println("Flyable working...");
	     flyingBird.fly();
	     }


}
