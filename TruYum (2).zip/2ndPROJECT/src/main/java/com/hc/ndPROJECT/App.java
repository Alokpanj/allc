package com.hc.ndPROJECT;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
        System.out.println( "2ND" );
    }
}
