import java.util.Scanner;

public class Course {

	
	public static void main(String[] args) {
		

		Scanner in = new Scanner(System.in);
		System.out.println("Enter no of course:");
		int course = in.nextInt();
		in.nextLine();
		
		int i, j, count = 0;
		
		String str[] = new String[course];
		if(course <=20 && course >=1){
			System.out.println("Enter course names:");
			for(i =0; i<course;i++){
				str[i]= in.nextLine();
		
		}
		
		System.out.println("Enter the course to be searched:");
		String search = in.nextLine();
		for(j=0; j<course; j++){
			if(str[j].equals(search)){
				count++;
				break;
			}

		}
		if(count == 1) {		
			System.out.println(search+" course is available" );
		}
		else {
			System.out.println(search+ " course is not available");
	
		}
		
		}
		
		else {
			System.out.println("Invalid Range");
		}
	}
}
