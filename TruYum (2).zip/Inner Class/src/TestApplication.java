import java.util.*;
public class TestApplication {

	public static void main(String[] args) {
		//AddressBook obj =new AddressBook();
		//AddressBook.Address a = obj.new Address();
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the permanent address");
		System.out.println("Enter the house name");
		String s1=sc.nextLine();
		
		
		
		System.out.println("Enter the street");
		String s2=sc.nextLine();
		
		
		System.out.println("Enter the city");
		String s3=sc.nextLine();
		
		
		System.out.println("Enter the state");
		String s4=sc.nextLine();
		  //Outer.Inner in = new Outer().new Inner(); 
		AddressBook.Address permAddress=new AddressBook().new Address();
		permAddress.setName(s1);
		permAddress.setStreet(s2);
		permAddress.setCity(s3);
		permAddress.setState(s4);
		System.out.println("Enter the temporary address");
		System.out.println("Enter the house name");
		AddressBook.Address tempAddress= new AddressBook().new Address();
		String s5=sc.nextLine();
		
		
		System.out.println("Enter the street");
		String s6=sc.nextLine();
		
		
		System.out.println("Enter the city");
		String s7=sc.nextLine();
		
		
		System.out.println("Enter the state");
		String s8=sc.nextLine();
		tempAddress.setName(s5);
		tempAddress.setStreet(s6);
		tempAddress.setCity(s7);
		tempAddress.setState(s8);

		
		System.out.println("Enter the phone number");
		long ph=sc.nextLong();
		AddressBook obj=new AddressBook();
		obj.setPhoneNumber(ph);
		
		System.out.println("Permanent address");
		System.out.println("House name:"+s1);
		System.out.println("Street:"+s2);
		System.out.println("City:"+s3);
		System.out.println("State:"+s4);
		
		System.out.println("Temporary address");
		System.out.println("House name:"+s5);
		System.out.println("Street:"+s6);
		System.out.println("City:"+s7);
		System.out.println("State:"+s8);
		System.out.println("Phone number");
		System.out.println(ph);
			}

}
