import java.util.Scanner;

public class Customer {

	public static void main(String[] args) {
		
		Scanner in = new Scanner(System.in);
		System.out.println("Enter your name:");
		String str1 = in.nextLine();
		
		System.out.println("Enter age:");
		String str2 = in.nextLine();
		
		System.out.println("Enter gender:");
		String str3 = in.nextLine();
		
		System.out.println("Hailing from:");
		String str4 = in.nextLine();
		
		System.out.println("Welcome "+str1 +"!");
		System.out.println("Age:"+str2);
		System.out.println("Gender:"+str3);
		System.out.println("City:"+str4);
		

	}

}
