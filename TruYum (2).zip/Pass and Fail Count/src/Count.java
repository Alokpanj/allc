import java.util.Scanner;

public class Count {

	public static void main(String[] args) {

		
		Scanner in = new Scanner(System.in);
		System.out.println("Enter the no of subjects:");
		int subject = in.nextInt();
		
		if(subject<=0){
			System.out.println("Invalid input range");
			System.exit(0);
		}
		
		int arr[] = new int[subject];
				
		int i, pass =0, fail =0;
		
		for( i= 0; i<subject; i++){
			arr[i] = in.nextInt();
			if(arr[i]>=50){
				pass++;
			}
			else{
				fail++;
			}
		}
		if(pass==subject) {
			System.out.println("Ram passed in all subjects");
		}
		else if(fail==subject) {
			System.out.println("Ram failed in all subjects");
		}
		else {
			System.out.println("Ram passed in " + pass + " subjects and failed in " + fail + " subjects");
		}
	}

}
