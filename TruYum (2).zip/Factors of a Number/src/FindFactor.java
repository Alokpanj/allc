import java.util.Scanner;

public class FindFactor {
    
	private static Scanner sc;
	
	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		
		int i;
		
		int num = sc.nextInt();
		
		if(num<0){
			num = -(num);
			
		}
		if(num == 0)
		{
			System.out.println("No Factors");
		}
		
		for( i = 1; i <= num; i++) {
			if(num%i == 0) {
				System.out.format(" %d ", i);
				
			}
			
		}
	}
}




/*import java.util.Scanner;

public class FindFactor {
    
	private static Scanner sc;
	
	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		
		
		
		int num = sc.nextInt();
		
		if(num<0){
			num = -(num);
			
		}
		if(num == 0)
		{
			System.out.println("No Factors");
		}
		
		for(int  i = 1; i <= num; i++) {
			if(num%i == 0) {
				System.out.format(" %d ", i);
				
			}
			
		}
	}
}*/
