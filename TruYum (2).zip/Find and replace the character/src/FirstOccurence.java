import java.util.Scanner;

public class FirstOccurence {

	public static void main(String[] args) {
		
		
		
		Scanner in = new Scanner(System.in);
		System.out.println("Enter the string:");
		String str1 = in.nextLine();
		System.out.println("Enter the character to be searched:");
		String str2 = in.nextLine();
		System.out.println("Enter the character to replace:");
		String str3 = in.nextLine();
		System.out.println(str1.replace("str2" , "str3"));
		
		
		
	}

}


/*      
 * 
 *  
 *  System.out.println("Enter the character to be searched:");
	    String str2 = in.nextLine();
		
		System.out.println("Enter the character to replace:");
		String str3 = in.nextLine();
		
 *  
 *  
 *  
 *  // Java code to demonstrate the 
 
// working of replace() 
public class rep1 { 
public static void main(String args[]) { 
		
	// Initialising String 
	String Str = new String("Welcome to geeksforgeeks"); 
		
	// Using replace to replace characters 
	System.out.print("After replacing all o with T : " ); 
	System.out.println(Str.replace('o', 'T')); 
		
	// Using replace to replace characters 
	System.out.print("After replacing all e with D : " ); 
	System.out.println(Str.replace('e', 'D')); 
		
} 
} 
*/