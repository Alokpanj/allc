package cognizant.tekstac;

import java.util.Scanner;

public class Palindrome{

	public static void main(String[] args) {

		Scanner S = new Scanner(System.in); 
		int n = S.nextInt();
		
		
		if(n<0){
			System.out.println("Invalid Input");
		}
			else{
				
				
				int num=n, sum = 0;
				while(n>0){
					int r=n%10;
					sum=sum*10+r;
					n=n/10;
				}
				
				
				if (sum == num)  
			         System.out.println("Palindrome");  
			      else  
			         System.out.println("Not a Palindrome");   
			      
			
		}
		
		
	}

}
/*
 * 
 * 
 * 
 * 
 * 
 * 
 * 
 * 
 * 
 * String original, reverse = ""; 
	      Scanner n = new Scanner(System.in);   
	      n.nextLine(); 
	      
	      if( original < 0)
	      System.out.println("Invalid Input");
	      
	      else{
	    	    
	      int length = original.length();   
	      for ( int i = length - 1; i >= 0; i-- )  
	         reverse = reverse + original.charAt(i);
	     
	     
	      
	      if (original.equals(reverse))  
	         System.out.println("Palindrome");  
	      else  
	         System.out.println("Not a Palindrome");   
	      }
 * 
 * 
 * 
 * 
 * 
 * 
 * 
 * 
 * */
 