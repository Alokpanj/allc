package com.ui;
import java.util.*;

import com.utility.GPACalculator;
public class UserInterface {

		public static void main(String[] args) {
			Scanner kb=new Scanner(System.in);
		GPACalculator gp=new GPACalculator();
			while(true)
			{
			    System.out.println("1. Add Grade");
			    System.out.println("2. Calculate GPA");
			    System.out.println("3. Exit");
			    System.out.println("Enter your choice");
			   int a=kb.nextInt();
			   if(a==1)
			   { System.out.println("Enter the obtained grade");
			     String str=kb.next();
			       gp.addGradePoint(str.charAt(0));
			   }
			   else if(a==2)
			   {
			        System.out.println("GPA Scored");
			         System.out.println(gp.calculateGPAScored());
			   }
			   else if(a==3)
			   {
			      break;
			   }
			}
			
		}

	}

