
public class InvalidCityPincodeException extends Exception{

	public InvalidCityPincodeException(String string) {
		// TODO Auto-generated constructor stub
		super(string);
	}
	public InvalidCityPincodeException() {
		// TODO Auto-generated constructor stub
		super();
	}

}
