//make the required changes to this class so that InvalidPackageIdException is of type exception.
public class InvalidPackageIdException extends Exception {

	public InvalidPackageIdException() {

	}

	public InvalidPackageIdException(String string) {
		super(string);
	}

}
