
public class InvalidCityPincodeException extends Exception{
	InvalidCityPincodeException(){
		super();
	}
	InvalidCityPincodeException(String s){
		super(s);
	}
}
