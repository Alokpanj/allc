public interface Spatial {

}
