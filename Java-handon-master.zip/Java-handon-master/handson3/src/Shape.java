
public abstract class Shape {

}
