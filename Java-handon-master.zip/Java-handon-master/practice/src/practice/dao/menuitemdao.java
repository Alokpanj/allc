package practice.dao;

import java.util.ArrayList;

import practice.model.menuitem;

public interface menuitemdao {

		public ArrayList<menuitem> getmenuitemlistadmin();
		
}
