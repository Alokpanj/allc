import java.util.ArrayList;

public class ArrayListTrial {
public static void main(String ar[])
{
ArrayList<Integer>asd=new ArrayList<>();
asd.add(1);
asd.add(2);
asd.add(3);
asd.add(1,5);

	System.out.println(asd);
}
}
