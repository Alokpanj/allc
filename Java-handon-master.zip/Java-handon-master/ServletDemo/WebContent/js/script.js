
function sandOver(asd){
       var ur='file:///C:/Users/841137/Desktop/truyum-ui/Images/'+asd+'.jpg';
        document.body.style.backgroundImage="url("+ur+")";
        document.body.style.backgroundSize='100% 100%';
        //"C:\Users\841137\Desktop\truyum-ui\Images\san.jpg"></img>
     
}
function clearImages()
{
    document.body.style.backgroundImage="url()";
}
function ar(){
var a=new Array();
a[0]="df";
a[1]="df";
a[2]="df";
document.write(a[0,1,2]);
}