import java.util.Scanner;

public class TestApplication {

	public static void main(String[] args) {
		Scanner s=new Scanner(System.in);
		System.out.println("Enter the permanent address");
		System.out.println("Enter the house name");
		String houseName=s.nextLine();
		System.out.println("Enter the street");
		String street=s.nextLine();
		System.out.println("Enter the city");
		String city=s.nextLine();
		System.out.println("Enter the state");
		String state=s.nextLine();
		
		AddressBook.Address permAddress=new AddressBook().new Address();
		permAddress.setName(houseName);
		permAddress.setStreet(street);
		permAddress.setCity(city);
		permAddress.setState(state);
		
		System.out.println("Enter the temporary address");
		System.out.println("Enter the house name");
		String tempHouseName=s.nextLine();
		System.out.println("Enter the street");
		String tempStreet=s.nextLine();
		System.out.println("Enter the city");
		String tempCity=s.nextLine();
		System.out.println("Enter the state");
		String tempState=s.nextLine();
		
		AddressBook.Address tempAddress=new AddressBook().new Address();
		tempAddress.setName(tempHouseName);
		tempAddress.setStreet(tempStreet);
		tempAddress.setCity(tempCity);
		tempAddress.setState(tempState);
		
		System.out.println("Enter the phone number");
		
		long phoneNumber=s.nextLong();
		
		AddressBook adBook=new AddressBook();
		adBook.setPhoneNumber(phoneNumber);
	
		
		
		
		System.out.println("Permanent address");
		System.out.println("House name:"+permAddress.getName());
		System.out.println("Street:"+permAddress.getStreet());
		System.out.println("City:"+permAddress.getCity());
		System.out.println("State:"+permAddress.getState());
		
		System.out.println("Temporary address");
		System.out.println("House name:"+tempAddress.getName());
		System.out.println("Street:"+tempAddress.getStreet());
		System.out.println("City:"+tempAddress.getCity());
		System.out.println("State:"+tempAddress.getState());
		System.out.println("Phone number");
		System.out.println(adBook.getPhoneNumber());
	
	
	}
}