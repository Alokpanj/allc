
public class Loan {

	public double calculateLoanAmount(Employee employeeObj) {
		return employeeObj instanceof PermanentEmployee ?employeeObj.getSalary()*(15/100.0):employeeObj.getSalary()*(10/100.0);
	}

}
