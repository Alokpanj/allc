package com.ui;
import com.utility.*;
import java.util.*;

public class UserInterface {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner s =new Scanner(System.in);
		System.out.println("Enter the no of Policy names you want to store");
		int n=s.nextInt();
		
		Bazaar b=new Bazaar();
		Map<Integer,String> map=new TreeMap<Integer,String>();
	    for(int i=0;i<n;i++)
	    {
	    	System.out.println("Enter the Policy ID");
	    	int policyId=s.nextInt();
	    	s.nextLine();
	  
	    	System.out.println("Enter the Policy Name");
	    	String policy=s.nextLine();
	    	
	    	b.addPolicyDetails(policyId,policy);
	    
	    }
	    Map<Integer,String> m=b.getPolicyMap();
	    Set set=m.entrySet();
	    Iterator it=set.iterator();
	    while(it.hasNext())
	    {
	    	Map.Entry entry=(Map.Entry)it.next();
	    	System.out.println(entry.getKey()+" "+entry.getValue());
	    }
	   System.out.println("Enter the policy type to be searched");
	   String policyType=s.nextLine();
	   List<Integer> tempList=b.searchBasedOnPolicyType(policyType);
	   for(int i: tempList)
	   {
		   System.out.println(i);
	   }
		

	}

}
