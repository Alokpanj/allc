import java.util.Scanner;

public class AccountDetails{
	Scanner sc = new Scanner(System.in);
	public static void main(String[] args) {
		AccountDetails acc= new AccountDetails();
		Account ac=acc.getAccountDetails();
		ac.withdraw(acc.getWithdrawAmount());
	}
	public Account getAccountDetails(){
		boolean b= true;
		Account ac = new Account();
		System.out.println("Enter account id:");
		ac.setAccountId(sc.nextInt());
		System.out.println("Enter account type:");
		ac.setAccountType(sc.next());
		while(b){
			System.out.println("Enter balance:");
			int k=sc.nextInt();
			if(k>0){
				ac.setBalance(k);
				b=false;
			}else{
				System.out.println("Balance should be positive");
			}
		}
		return ac;
	}
	public int getWithdrawAmount(){
		int ret=0;
		boolean b= true;
		while(b){
			System.out.println("Enter amount to be withdrawn:");
			int k=sc.nextInt();
			if(k>0){
				ret=k;
				b=false;
			}else{
				System.out.println("Amount should be positive");
			}
			
		}
		return ret;
	}
}