import java.util.Arrays;
import java.util.Scanner;

class HighestMarkPerSem
{
	public static void main(String[] args)
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter no of semester:");
		int n=sc.nextInt();
		int i=1,j,k,y;
		int ns[]=new int[n];
		int maxmark[]=new int[n];

		
			for(j=0;j<n;j++)
			{	System.out.println("Enter no of subjects in "+(j+1)+" semester:");
				ns[j]=sc.nextInt();
			
			}
			
		
			
			for(y=0;y<n;y++)
			{	System.out.println("Marks obtained in semester "+(y+1)+":");
				int mrk[]=new int[ns[y]];
				for(k=0;k<ns[y];k++)
				{
					mrk[k]=sc.nextInt();
					if(mrk[k]<0 || mrk[k]>100)
					{
						System.out.println("You have entered invalid mark.");
						System.exit(0);
					}
				}
				Arrays.sort(mrk);
				maxmark[y]=mrk[mrk.length-1];
			}
			
		
	
			
			for(int m=0;m<n;m++)
			{	System.out.println("Maximum mark in "+(m+1)+" semester:");
				System.out.println(maxmark[m]);
			}
		}
	}
