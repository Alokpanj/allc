import java.util.Scanner;

public class Main {
	public static void main(String ar[])
	{
		Hosteller hst = getHostellerDetails();
		System.out.println(hst.getStudentId() +" " + hst.getName()  +" " + hst.getDepartmentId()  +" " + hst.getGender()  +" " + hst.getPhone()  +" " + hst.getHostelName()  +" " + hst.getRoomNumber());
	}
	public static Hosteller getHostellerDetails(){
		Hosteller hst = new Hosteller();
	
		String nphno;
		System.out.println("Enter the Details:");
		System.out.println("Student Id");
		Scanner kb = new Scanner(System.in);
		int id = kb.nextInt();
		System.out.println("Student Name");
		kb.nextLine();
		String name = kb.nextLine();
		System.out.println("Department Id");
		int dId = kb.nextInt();
		System.out.println("Gender");
		
		String gen = kb.next();
		System.out.println("Phone Number");
		nphno = kb.next();
		System.out.println("Hostel Name");
		String hstl = kb.next();
		System.out.println("Room Number");
		int rno = kb.nextInt();
        System.out.println("Modify Room Number(Y/N)");
		String mroom = kb.next();
		if(mroom.equalsIgnoreCase("Y"))
		{
			System.out.println("New Room Number");
			rno= kb.nextInt();
		}
		
		System.out.println("Modify Phone Number(Y/N)");
		String mphn = kb.next();
		if(mphn.equalsIgnoreCase("Y"))
		{
			System.out.println("New Phone Number");
			 nphno = kb.next();
		}
		hst.setStudentId(id);
		hst.setName(name);
		hst.setDepartmentId(dId);
		hst.setGender(gen);
		hst.setPhone(nphno);
		hst.setHostelName(hstl);
		hst.setRoomNumber(rno);
		
		
		return hst;
	}
}