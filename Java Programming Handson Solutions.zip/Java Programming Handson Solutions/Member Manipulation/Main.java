import java.util.ArrayList;
import java.util.Scanner;

public class Main{
	public static void main(String[] args){
		Scanner sc = new Scanner(System.in);
		Library lib = new Library();
		ArrayList<Member> ar = new ArrayList<>();
		Member b = new Member();
		int i ;
		do{
		System.out.println("1.Add Member");
		System.out.println("2.View All Members");
		System.out.println("3.Search Member by address");
		System.out.println("5.Exit");
		
		System.out.println("Enter your choice:");
		i = sc.nextInt();
		sc.nextLine();
		switch(i){
		case 1:
			System.out.println("Enter the id:");
			int id = sc.nextInt();
			sc.nextLine();
			System.out.println("Enter the name:");
			String name = sc.nextLine();
			System.out.println("Enter the address:");
			String add = sc.nextLine();
			b.setMemberId(id);
			b.setMemberName(name);
			b.setAddress(add);
			lib.addMember(b);
			break;
		case 2:
			lib.viewAllMembers();
			break;
		case 3:
			System.out.println("Enter the address:");
			String address = sc.nextLine();
			ar.addAll(lib.viewMembersByAddress(address));
			if(ar.isEmpty()){
				System.out.println("None of the member is from "+address);
			}
			else{
			for (Member b1 : ar) {
				System.out.println("Id:"+b1.getMemberId());
				System.out.println("Name: "+b1.getMemberName());
				System.out.println("Address:"+b1.getAddress());
			}
			}
			break;
		case 4:
			System.exit(0);
			break;
				
		}
		}while(i!=4);
	}
}