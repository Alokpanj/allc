public class Student{
	private int id;
	private String name;
	private int[] marks;
	private float average;
	private char grade;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int[] getMarks() {
		return marks;
	}
	public void setMarks(int[] marks) {
		this.marks = marks;
	}
	public float getAverage() {
		return average;
	}
	public void setAverage(float average) {
		this.average = average;
	}
	public char getGrade() {
		return grade;
	}
	public void setGrade(char grade) {
		this.grade = grade;
	}
	
	public Student(int id, String name, int[] marks) {
		super();
		this.id = id;
		this.name = name;
		this.marks = marks;
	}
	public void calculateAvg(){
		int size=getMarks().length;
		int sum=0;
	  for(int mark:getMarks()){
		  sum=sum+mark;
	  }
	  setAverage((float)sum/size);
	}
	public void findGrade(){
		float avg = getAverage();
		if(avg >=80 && avg<=100){
			setGrade('O');
		}else{
			setGrade('A');
		}
		for(int mark:getMarks()){
			  if(mark<50){
				  setGrade('F');
			  }
		  }
	}
	
}