import java.util.Scanner;

class Palindrome
{
	public static void main(String[] args)
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the word:");
		String s1=sc.nextLine();
		for(int i=0;i<s1.length();i++)
		{if (s1.valueOf(s1.charAt(i)).matches("[^a-zA-Z0-9]")) {
			System.out.println("Invalid Input");
			System.exit(0);
		}
		}
		
			StringBuilder sb=new StringBuilder(s1);
		
		sb.reverse();
		String s2=sb.toString();
		if(s1.equalsIgnoreCase(s2))
		{
			System.out.println(s1+" is a Palindrome");
		}
		else
		{
			System.out.println(s1+" is not a Palindrome");
		}
	}
	
}
