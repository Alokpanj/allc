import java.util.Scanner;

public class IncrementCalculation {
	public static void main(String[] args) {
		Scanner s = new Scanner(System.in);
		System.out.println("Enter the salary");
		int salary = s.nextInt();
		System.out.println("Enter the Performance appraisal rating");
		float rating = s.nextFloat();
		int increment;
		if(salary<=0||!(rating>=1 && rating <=5)) {
			System.out.println("Invalid Input");
		}
		 
		else if(rating>=1 && rating<=3) {
			increment = ((salary/100)*10)+salary;
			System.out.println(increment);
		}
		else if(rating>=3.1 && rating<=4){
			increment = ((salary/100)*25)+salary;
			System.out.println(increment);
		}
		
		else {
			increment = ((salary/100)*30)+salary;
			System.out.println(increment);
		}
	}
}