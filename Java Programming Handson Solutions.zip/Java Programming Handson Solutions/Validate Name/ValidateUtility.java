import java.util.Scanner;
import java.util.regex.Pattern;
public class ValidateUtility
{
    public static void main(String args[])
    {	String name;
		String pro_name;
        //fill code here
    	 Scanner s=new Scanner(System.in);
    	 name=s.nextLine();
    	 pro_name=s.nextLine();
    	
    	 Validate validate = validateEmployeeName();
    	 System.out.println(validate.validateName(name)?"Employee name is valid":"Employee name is invalid");
    	 
    	 validate = validateProductName();
    	 System.out.println(validate.validateName(pro_name)?"Product name is valid":"Product name is invalid");
    	

    	 s.close();
    }
    
    public static Validate validateEmployeeName() 
    {
        //fill code here
    	return (String s)-> Pattern.matches("[a-zA-Z ]{5,20}",s);
    }
    
    public static Validate validateProductName() 
    {
        //fill code here
    	return (String s)-> Pattern.matches("[A-Za-z][0-9]{5}",s);
    }
}