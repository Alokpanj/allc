import java.util.Scanner;

class Numerology
{
	public static void main(String[] args)
	{	Scanner sc=new Scanner(System.in);
		System.out.println("Enter your name:");
		 String s=sc.next();
		 int sum=0;
		 if(!s.matches("^[a-zA-Z]*$"))
	        {
	        	 System.out.println("Invalid name");
	        	 System.exit(0);
	        }
		 for(int i=0;i<s.length();i++)
		 {		if(s.charAt(i)<65 || s.charAt(i)>90)
		 	{
			 System.out.println("Invalid name");
        	 System.exit(0);
		 	}
			 if(s.charAt(i)=='A'||s.charAt(i)=='I'||s.charAt(i)=='J'||s.charAt(i)=='Q'||s.charAt(i)=='Y')
			 {
				 sum=sum+1;
			 }
			 else if(s.charAt(i)=='B'||s.charAt(i)=='K'||s.charAt(i)=='R')
			 {
				 sum=sum+2;
			 }
			 else if(s.charAt(i)=='C'|| s.charAt(i)=='G'||s.charAt(i)=='L'||s.charAt(i)=='S')
			 {
				 sum=sum+3;
			 }
			 else if(s.charAt(i)=='D'||s.charAt(i)=='M'||s.charAt(i)=='T')
			 {
				 sum=sum+4;
			 }
			 else if(s.charAt(i)=='E'|| s.charAt(i)=='H'||s.charAt(i)=='N'||s.charAt(i)=='X')
			 {
				 sum=sum+5;
			 }
			 else if(s.charAt(i)=='F'||s.charAt(i)=='P')
			 {
				 sum=sum+8;
			 }
			
			 else if(s.charAt(i)=='O'||s.charAt(i)=='Z')
			 {
				 sum=sum+7;
			 }
			
			 else if(s.charAt(i)=='U'||s.charAt(i)=='V'||s.charAt(i)=='W')
			 {
				 sum=sum+6;
			 }
			
			
		 }
		 System.out.println("Your numerology no is:"+sum);
    	
		 
	}
}