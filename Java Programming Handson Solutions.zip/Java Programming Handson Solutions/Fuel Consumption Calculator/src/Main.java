import java.util.*;
public class Main {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the no of liters to fill the tank");
		int lit=sc.nextInt();
		if(lit<=0)
		{
			System.out.println(lit+" is an Invalid Input");
			System.exit(0);
		}
		System.out.println("Enter the distance covered");
		int dis=sc.nextInt();
		if(dis<=0)
		{
			System.out.println(dis+" is an Invalid Input");
			System.exit(0);
		}
		double d=((double)lit/dis)*100;
		float m=(float) (dis*0.6214);
		float g=(float) (lit*0.2642);
		System.out.println("Liters/100KM");
		System.out.printf("%.2f",d);
		System.out.println("\nMiles/gallons");
		System.out.printf("%.2f",m/g);
		sc.close();
	}

}
