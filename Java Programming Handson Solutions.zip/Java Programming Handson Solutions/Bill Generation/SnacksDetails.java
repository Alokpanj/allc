import java.util.Scanner;

class SnacksDetails
{
	public static void main(String[] args)
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the no of pizzas bought:");
		int npiz=sc.nextInt();
		System.out.println("Enter the no of puffs bought:");
		int npuf=sc.nextInt();
		System.out.println("Enter the no of cool drinks bought:");
		int ncd=sc.nextInt();
		
		System.out.println("Bill Details");
	
		
		System.out.println("No of pizzas:"+npiz);
		System.out.println("No of puffs:"+npuf);
		System.out.println("No of cooldrinks:"+ncd);
		
		System.out.println("Total price="+((npiz*100)+(npuf*20)+(ncd*10)));
		System.out.println("ENJOY THE SHOW!!!");
	}
}