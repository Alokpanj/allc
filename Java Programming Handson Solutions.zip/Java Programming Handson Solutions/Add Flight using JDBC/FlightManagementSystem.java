import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.SQLSyntaxErrorException;
import java.sql.Statement;

public class FlightManagementSystem {
	public boolean addFlight(Flight flightObj)
	{
	
	//	Statement stmt=null;
	int i=0;	
		try
		{
	 Connection con=DB.getConnection();
	 
	 int id=flightObj.getFlightId();
	 String source= flightObj.getSource();
	 String dest=flightObj.getDestination();
	 int noofseats=flightObj.getNoOfSeats();
	 double flightFare=flightObj.getFlightFare();
	 
	 System.out.println(id+" "+source+" "+dest+" "+noofseats+" "+flightFare);
	 
	 /*stmt=con.createStatement();
	 String sql="insert into flight values(id,source,dest,noofseats,flightFare)";
	 int i=stmt.executeUpdate(sql);
	System.out.println(i); */
	PreparedStatement ps=con.prepareStatement("insert into flight values(?,?,?,?,?)");
	
	 ps.setInt(1,id);
	 ps.setString(2,source);
	 ps.setString(3, dest);
	 ps.setInt(4, noofseats);
	 ps.setDouble(5, flightFare);
	   i=ps.executeUpdate();
					 
	 //"("+flightObj.getFlighId()+","+flightObj.getSource()+","+flightObj.getDestination()+
	 //","+flightObj.getNoOfSeats()+","+flightObj.getFlightFare()+")"
	 
			 System.out.println("Inserted Successfully");
			 
	
	 
		}
		catch(SQLException e)
		{
			e.printStackTrace();
			
		}
		catch(ClassNotFoundException e1)
		{
			e1.printStackTrace();
		}
		
		if(i==1)
		{
		    return true;
		}
		else 
		{
		    return false;
		}
	}

}
