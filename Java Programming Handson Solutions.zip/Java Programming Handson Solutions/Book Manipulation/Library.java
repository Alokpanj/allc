import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class Library{
	private ArrayList<Book> bookList = new ArrayList<>();

	public ArrayList<Book> getBookList() {
		return bookList;
	}

	public void setBookList(ArrayList<Book> bookList) {
		this.bookList = bookList;
	}
	
	public void addBook(Book bobj){
		int id = bobj.getIsbnno();
		bobj.setIsbnno(id);
		String bookName = bobj.getBookName();
		bobj.setBookName(bookName);
		String author = bobj.getAuthor();
		bobj.setAuthor(author);
		bookList.add(bobj);
	}
	
	public boolean isEmpty(){
		if(bookList.isEmpty())
			return true;
		else
			return false;
	}
	
	public ArrayList<Book> viewAllBooks(){
		return bookList;
		
	}
	
	public ArrayList<Book> viewBooksByAuthor(String author){
		ArrayList<Book> newList = new ArrayList<>();
		if(!bookList.isEmpty()){
		for(Book b:bookList)
			if(b.getAuthor().equals(author)){
				newList.add(b);
				
			}
		if(newList.size()==0){
			System.out.println("The list is empty");
		}
		}
		return newList;
	}
	
	public int countnoofbook(String bname){
		int c=0;
		for(Book b : bookList){
			if(b.getBookName()==bname){
				c++;
			}
		}
		return c;
		
	}
	
}