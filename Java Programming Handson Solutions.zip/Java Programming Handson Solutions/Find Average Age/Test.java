import java.util.Scanner;

public class Test
{
	
	public static void main(String args[])
	{
		int arr[]=new int[20];
		float s=0;
		float avg;
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter total no.of employees:");
		int x=sc.nextInt();
		if(x>=2)
		{
		System.out.println("Enter the age for "+x+" employees:");
		for(int i=0;i<x;i++)
		{
			arr[i]=sc.nextInt();
			if(arr[i]>=28 && arr[i]<=40)
			{
			      s=s+arr[i];
		}
			else
			{
				System.out.println("Invalid age encountered!");
				return;
			}
		}
		avg=(s/x);
		System.out.println("The average age is "+String.format("%.2f", avg));
	}
		else
		{
			System.out.println("Please enter a valid employee count");
		}
	}
}