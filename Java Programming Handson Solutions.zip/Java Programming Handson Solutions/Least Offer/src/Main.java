 import java.util.*;
    
    class Product{
         int price;
        int discount;
        String name;
        public Product(String name,int price,int discount)
       {
            this.name = name;
           this.price = price;
           this.discount = discount;
       }
    }
   
   public class Main{
        public static void main (String[] args) {
         Scanner sc=new Scanner(System.in);
         
         int t = sc.nextInt();
        sc.nextLine();
        
         ArrayList<Product> al = new ArrayList<>();
        
         while(t-->0)
        {
             String temp  = sc.nextLine();
             
             String[]str = temp.split(",");
       
            String name = str[0];
            int price = Integer.parseInt(str[1]);
             int dis = Integer.parseInt(str[2]);
            
            Product p = new Product(name,price,dis);
            al.add(p);
             
        }
        int ans=Integer.MAX_VALUE;
        for(int i=0; i<al.size(); i++)
        {
           int dis = (int)(al.get(i).price * (al.get(i).discount/100.0));
          if(dis<ans)
                ans = dis;
         System.out.println( al.get(i).price  + " " + al.get(i).discount + " "+ans);
        }
        
         for(int i=0; i<al.size(); i++)
         {
             if( (int)(al.get(i).price * (al.get(i).discount/100.0)) == ans)
               System.out.println(al.get(i).name);
        }
           
        }
   }