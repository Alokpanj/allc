import java.util.Scanner;

public class CompatibleArrays
{
	public static void main(String args[])
	{
		int arr[]=new int[100];
		int arr1[]=new int[100];
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the size for First array:");
		int x=sc.nextInt();
		if(x<=0)
		{
			System.out.println("Invalid array size");
			return;
		}
		System.out.println("Enter the elements for First array:");
		for(int i=0;i<x;i++){
			arr[i]=sc.nextInt();
		}
		System.out.println("Enter the size for Second array:");
		int y=sc.nextInt();
		if(y<=0)
		{
			System.out.println("Invalid array size");
			return;
		}
		System.out.println("Enter the elements for Second array:");
		for(int i=0;i<y;i++){
			arr1[i]=sc.nextInt();
		}
		if(x!=y){
			System.out.println("Arrays are Not Compatible");
			return;
		}
		int c=0;
		for(int i=0;i<y;i++){
			if(arr[i]>=arr1[i])
			{
				c=c+1;	
			}
		}
		if(c==y)
		{
			System.out.println("Arrays are Compatible");
		}
			else
			{
				System.out.println("Arrays are Not Compatible");
			}
		}
	}
