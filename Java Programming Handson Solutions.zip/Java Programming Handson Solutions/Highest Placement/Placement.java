import java.util.Scanner;

class Placement
{
public static void main(String[] args){
		
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the no of students placed in CSE:");
		int ncs=sc.nextInt();
		System.out.println("Enter the no of students placed in ECE:");
		int nec=sc.nextInt();
		System.out.println("Enter the no of students placed in MECH:");
		int nmech=sc.nextInt();
		
		if(ncs==nec && nec==nmech)
		{
			System.out.println("None of the department has got the highest placement");
		}
		else if(ncs<0||nec<0||nmech<0)
		{
			System.out.println("Input is Invalid");
		}
		else if(ncs>nec && ncs>nmech)
		{
			System.out.println("Highest placement");
			System.out.println("CSE");
		}
		else if(ncs==nec && ncs>nmech)
		{	System.out.println("Highest placement");
			System.out.println("CSE");
			System.out.println("ECE");
				
		}
		else if(ncs==nmech && ncs>nec)
		{
			System.out.println("Highest placement");
			System.out.println("CSE");
			System.out.println("MECH");
				
		}
		else if(nec>ncs && nec>nmech)
		{
			System.out.println("Highest placement");
			System.out.println("ECE");
		}
		else if(nec==nmech && nec>ncs)
		{
			System.out.println("Highest placement");
			System.out.println("ECE");
			System.out.println("MECH");
				
		}
		else if(nmech>ncs && nmech>nec)
		{
			System.out.println("Highest placement");
			System.out.println("MECH");
		}
		
}
}