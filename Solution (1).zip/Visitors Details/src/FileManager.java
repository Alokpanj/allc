import java.awt.image.BufferedImageFilter;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;

//import necessary packages
 
 @SuppressWarnings("unchecked")//Do not delete this line
 public class FileManager 
 {
    
    static public File createFile()
    {
    	File f =null;
    try {
       f = new File("visitors.txt");
       f.createNewFile();
      
    } catch (IOException e) {
      System.out.println("An error occurred.");
      e.printStackTrace();
    }
    return f;//change the return type as per the requirement    
    }
    static public void writeFile(File f, String record)
	{
    	  try {
    	     // FileWriter myWriter = new FileWriter(f,true);
    		  
    	    //  myWriter.write(record);
    	      //myWriter.close();
    	      //System.out.println("Successfully wrote to the file.");
//    		  
//    BufferedWriter w = new BufferedWriter(new FileWriter(f,true));
//    
//    w.write(record);
//    w.close();
    		  FileWriter fileWriter = new FileWriter(f, true); //Set true for append mode
    		    PrintWriter printWriter = new PrintWriter(fileWriter);
    		    printWriter.println(record);  //New line
    		    printWriter.close();
    		  
    
    	  } catch (IOException e) {
    	       
    	      e.printStackTrace();
    	    }
	} 
	static public String[] readFile(File f)
	{
		FileReader fr;
		 String line = null;
		 List<String> lines = null;
		try {
			fr = new FileReader(f);
			 BufferedReader bufferedReader = new BufferedReader(fr);
		      lines = new ArrayList<String>();
		       
		         
		        while ((line = bufferedReader.readLine()) != null) 
		        {
		            lines.add(line);
		        }
		         
		        bufferedReader.close();
		         
		       
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
       
		 return lines.toArray(new String[lines.size()]);
	}
 }