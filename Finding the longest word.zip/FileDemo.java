import java.io.*;
import java.util.*;
import java.lang.*;
public class FileDemo{
    public static void main(String[] args)
    {
        File f = null;
        BufferedReader br = null;
        FileReader fr = null;
        String s = null,s1=null;
         String str[] = null;
         int max = 0;
        try{
          
            fr = new  FileReader("log.txt");
            br = new  BufferedReader(fr);
            while((s=br.readLine())!=null){
                 str = s.split(" ");
                 for(int  i = 0; i< str.length; i++ ){
                     if(max<str[i].length()){
                         s1 = str[i];
                         max  = str[i].length();
                     }
                 }
                
                }
        }catch(Exception e){
            e.printStackTrace();
        }
         System.out.println(s1);
    }
}
