import java.util.Date;
import java.net.SocketTimeoutException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.*;
import java.time.format.DateTimeParseException;
import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.time.temporal.*;

public class Main {
	public static void main(String args[])
	{	Date d1=null;
		Date d2=null;
		Date today=null;
		SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/yyyy HH:mm");
		Scanner s= new Scanner(System.in);
		try {
			today=formatter.parse("29/10/2019 20:10");
			formatter.format(today);
		} catch (Exception e) {
			// TODO: handle exception
		}
		System.out.println("In-time");
		String inTime=s.nextLine();
		try
		{
			d1 = formatter.parse(inTime);
			formatter.format(d1);
			if (d1.compareTo(today)>0||d1.compareTo(today)==0)
			{
				System.out.println(inTime+" is an Invalid In-Time");
				System.exit(0);
				
			}
			
		}
		catch(ParseException e)
		{
			System.out.println(inTime+" is an Invalid In-Time");
			System.exit(0);
			
		}
		System.out.println("Out-time");
		String outTime=s.nextLine();
		try
			{
				
				d2=formatter.parse(outTime);
				formatter.format(d2);
				if(d2.compareTo(d1)<0||d1.compareTo(d2)==0)		
				{
				System.out.println(outTime+" is an Invalid Out-Time");
				System.exit(0);
				}
		}
			catch(ParseException e)
			{
				System.out.println(outTime+" is an Invalid Out-Time");
				System.exit(0);
			}
			
		long diff = d2.getTime()-d1.getTime();
			
			int r=0;
			long diffInHours = diff/(60*60*1000);
			//long diffInMinutes=diffInHours*60;
			
			
			long rupees=diffInHours * 10;
			
			long temp=diff%3600000;
			if(temp!=0)
			{
				r=10;
				rupees=rupees+r;
			}
			
			System.out.println(rupees +" Rupees");
			
	}

}
