import java.util.*;
public class Main{
    public static void main(String[] args){
        Scanner s=new Scanner(System.in);
        System.out.println("Enter the flight id");
		int flightId=s.nextInt();
		//s.nextLine();
		System.out.println("Enter the source");
		String source=s.next();
		System.out.println("Enter the Destination");
		String dest=s.next();
		System.out.println("Enter the no of seats");
		int noOfSeats=s.nextInt();
		
	System.out.println("Enter the flight fare");
	double flightFare=s.nextDouble();
	
	Flight f=new Flight(flightId,source,dest,noOfSeats,flightFare);
	FlightManagementSystem fms=new FlightManagementSystem();
	
	boolean flag=fms.addFlight(f);
	if(flag==true)
	{
	    System.out.println("Flight details added successfully");
	}
	else 
	{
	    System.out.println("Addition not done");
	}
	
	
		
    }
  }
