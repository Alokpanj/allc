import java.util.Scanner;
public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
	                             Scanner sc = new Scanner(System.in);
	                                   Associate as = new Associate();
	                                   System.out.println("Enter the associate id:");
	                                  int Id= sc.nextInt();
	                                  as.setAssociateId(Id);
	                                  System.out.println("Enter the associate name:");
	                                    String Name=sc.next();
	                                  as.setAssociateName(Name);
	                                  System.out.println("Enter the number of days:");
	                                    int day=sc.nextInt();
	                                  as.trackAssociateStatus(day);
	                                   
	                                   
	                                   System.out.println("The associate "+as.getAssociateName()+" work status:"+as.getWorkStatus());

	}

}
