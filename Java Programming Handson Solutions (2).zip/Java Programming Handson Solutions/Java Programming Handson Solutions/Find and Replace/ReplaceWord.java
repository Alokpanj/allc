import java.util.Scanner;

public class ReplaceWord {
	public static void main(String arg[]) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the string:");
		String str = sc.nextLine();
		System.out.println("Enter the word to be searched:");
		String search = sc.next();
		System.out.println("Enter the word to be replaced:");
		String replace = sc.next();
		if(str.contains(search)){
		String Result = str.replaceAll(search, replace);
		System.out.println(Result);
		}
		else{
			System.out.println("The word "+search+" not found");
		}
	}
}