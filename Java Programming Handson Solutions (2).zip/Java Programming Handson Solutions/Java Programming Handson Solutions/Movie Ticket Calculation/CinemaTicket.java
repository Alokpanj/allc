import java.util.*;
import java.io.*;

public class CinemaTicket{
                public static void main(String[] args) throws Exception{
                                BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
                                System.out.println("Enter the no of ticket:");
                                int ticket = Integer.parseInt(br.readLine());
                                if(ticket < 5 || ticket > 40) {
                                                System.out.println("Minimum of 5 and Maximum of 40 Tickets");
                                                return;
                                }
                                System.out.println("Do you want refreshment:");
                                String refresh = br.readLine();
                                System.out.println("Do you have coupon code:");
                                String coupon = br.readLine();
                                System.out.println("Enter the circle:");
                                String circle = br.readLine();
                                
                                if(!(circle.equals("k") || circle.equals("q"))) {
                                                System.out.println("Invalid Input");
                                                return;
                                }
                                else {
                                                double cost = 0;
                                                double discount1 = 0;
                                                double discount2 = 0;
                                                double extras = 0;
                                                if(circle.equals("k"))
                                                                cost += (ticket * 75);
                                                else
                                                                cost += (ticket * 150);
                                                if(ticket > 20)
                                                                discount1 += (cost * 0.1);
                                                cost -= discount1;
                                                if(coupon.equals("y"))
                                                                discount2 += (cost * 0.02);
                                                cost -= discount2;
                                                if(refresh.equals("y"))
                                                                extras += (ticket * 50);
                                                cost += extras;
                                                System.out.printf("Ticket cost:%.2f",cost);
                                }
                }
}

//
