package com.spring.app;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Driver {
	public static void main(String[] args)
	{
		//Uncomment the below code to test your application
		ApplicationContext context = new ClassPathXmlApplicationContext("applicationContext.xml");
		DBConfig oracDb=(DBConfig)context.getBean("oracleDb");
		System.out.println(oracDb.getUrl());
		System.out.println(oracDb.getDriverName());
		System.out.println(oracDb.getUserName());
		System.out.println(oracDb.getPassword());
	}

}
