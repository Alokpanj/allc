import java.util.ArrayList;
import java.util.Scanner;

public class Main{
	public static void main(String[] args){
		Scanner sc = new Scanner(System.in);
		Library lib = new Library();
		ArrayList<Book> ar = new ArrayList<>();
		Book b = new Book();
		int i ;
		do{
		System.out.println("1.Add Book");
		System.out.println("2.Display all book details");
		System.out.println("3.Search Book by author");
		System.out.println("4.Count number of books - by book name");
		System.out.println("5.Exit");
		
		System.out.println("Enter your choice:");
		i = sc.nextInt();
		sc.nextLine();
		switch(i){
		case 1:
			System.out.println("Enter the isbn no:");
			int id = sc.nextInt();
			sc.nextLine();
			System.out.println("Enter the book name:");
			String name = sc.nextLine();
			System.out.println("Enter the author name:");
			String author = sc.nextLine();
			b.setIsbnno(id);
			b.setBookName(name);
			b.setAuthor(author);
			lib.addBook(b);
			break;
		case 2:
			lib.viewAllBooks();
			break;
		case 3:
			System.out.println("Enter the author name:");
			String author1 = sc.nextLine();
			ar.addAll(lib.viewBooksByAuthor(author1));
			if(ar.isEmpty()){
				System.out.println("None of the book published by the author "+author1);
			}
			else{
			for (Book b1 : ar) {
				System.out.println("ISBN no: "+b1.getIsbnno());
				System.out.println("Book name: "+b1.getBookName());
				System.out.println("Author name: "+b1.getAuthor());
			}
			}
			break;
		case 4:
			System.out.println("Enter the book name:");
			String bookname = sc.nextLine();
			lib.countnoofbook(bookname);
			break;
		case 5:
			System.exit(0);
			break;
				
		}
		}while(i!=5);
	}
}