import java.util.Scanner;

public class CumulativeSum{
                public static void main(String args[]){
                                Scanner sc = new Scanner(System.in);
                                System.out.println("Enter number of elements");
                                int n = sc.nextInt();
                                if(n<=0)
                                                System.out.println("Invalid Range");
                                
                                else{
                                                int arr[] = new int[n];
                                
                                                System.out.println("Enter the elements");
                                                for(int i=0;i<n;i++){
                                                                arr[i] = sc.nextInt();
                                                }
                                                int sum = 0;
                                                for(int i : arr){
                                                                sum+=i;
                                                                System.out.print(sum+" ");
                                                }
                                }
                                System.out.println();
                
}
}
