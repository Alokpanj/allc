public class Main{
    
    public static void main(String args[]){
    	Customer customerObj = new Customer(1, "customerName", "emailId");
        SavingsAccount savingsAccount = new SavingsAccount(123, customerObj, 10000, 10000);
        System.out.println(savingsAccount);
        savingsAccount.withdraw(1222);
        System.out.println(savingsAccount);
    }
}