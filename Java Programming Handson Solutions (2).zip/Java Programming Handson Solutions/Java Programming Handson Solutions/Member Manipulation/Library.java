import java.util.ArrayList;
import java.util.List;

public class Library{
	private List<Member> memberList = new ArrayList<Member>();

	public List<Member> getMemberList() {
		return memberList;
	}

	public void setMemberList(List<Member> memberList) {
		this.memberList = memberList;
	}
	
	public void addMember(Member memberObj){
		int id = memberObj.getMemberId();
		memberObj.setMemberId(id);
		String memName = memberObj.getMemberName();
		memberObj.setMemberName(memName);
		String add = memberObj.getAddress();
		memberObj.setAddress(add);
		memberList.add(memberObj);
	}

	public List<Member> viewAllMembers(){
		return memberList;
	}
	public List<Member> viewMembersByAddress(String address){
		ArrayList<Member> newList = new ArrayList<>();
		if(!memberList.isEmpty()){
		for(Member m:memberList)
			if(m.getAddress().equals(address)){
				newList.add(m);
				
			}
		if(newList.size()==0){
			System.out.println("The list is empty");
		}
		}
		return newList;
		
	}

}