import java.util.Scanner;

public class Division {
                public static void main(String[] args) {
                                System.out.println("Enter the numbers");
                                int number1 = new Scanner(System.in).nextInt();
                                int number2 = new Scanner(System.in).nextInt();
                                System.out.println(new Division().divideTwoNumbers(number1, number2));
                }
                public String divideTwoNumbers(int number1,int number2){
                                String result ="";
                                try{
                                                result = "The answer is  "+number1/(number2)+". Thanks for using the application.";
                                } catch (Exception e) {
                                                result = "Division by zero is not possible. Thanks for using the application.";
                                }finally {
                                                return result;
                                }
                }
}
