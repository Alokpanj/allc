import java.util.Scanner;

public class StudentMain{
	static Scanner sc = new Scanner(System.in);
	public static void main(String[] args) {
		Student st=getStudentDetails();
		st.calculateAvg();
		st.findGrade();
		System.out.println("Id:"+st.getId());
		System.out.println("Name:"+st.getName());
		System.out.printf("Average:%.2f\n",st.getAverage());
		System.out.println("Grade:"+st.getGrade());
	}
	public static Student getStudentDetails() {
		boolean noo=true,su=true;
		int noofsub=0;
		System.out.println("Enter the id:");
		int id=sc.nextInt();
		System.out.println("Enter the name:");
		String name=sc.next();
		while(noo){
			System.out.println("Enter the no of subjects:");
			int num=sc.nextInt();
			if(num>0){
				noofsub=num;
				noo=false;
			}else{
				System.out.println("Invalid number of subject");
			}
		}
		int[] mark= new int[noofsub];
		
		for(int i=0;i<noofsub;i++){
			while(su){
				System.out.printf("Enter mark for subject %d:\n",i+1);
				int num=sc.nextInt();
				if(num>0){
					mark[i]=num;
					su=false;
				}else{
					System.out.println("Invalid Mark");
				}
			}
			su=true;
		}
		Student st = new Student(id, name, mark);
		return st;
	}
}