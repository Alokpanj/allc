package com.cognizant.truyum.dao;

import static org.junit.Assert.*;

import org.junit.Test;

public class MenuItemDaoCollectionImplTest {
	public static void main(String[] args) {
		
	}
	@Test
	public  void testGetMenuItemListAdmin(){
		
	}
	@Test
	public void testGetMenuItemListCustomer(){
		
	}
	@Test
	public void testModifyMenuItem(){
		
	}
	@Test
	public void testGetMenuItem(){
		
	}
	
}
