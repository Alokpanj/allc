package com.cognizant.truyum.dao;

import java.awt.List;

public interface CartDao {
	void addCartItem(long userId,long menuItemId);
	List getAllCartItems(long userId);
	void removeCartItem(long userId,long menuItemId);
}
