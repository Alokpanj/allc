package com.cognizant.truyum.dao;

import java.awt.List;

public class CartDaoSqlImpl implements CartDao {
	
	@Override
	public void addCartItem(long userId, long menuItemId) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public List getAllCartItems(long userId) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void removeCartItem(long userId, long menuItemId) {
		// TODO Auto-generated method stub
		
	}
	
}
