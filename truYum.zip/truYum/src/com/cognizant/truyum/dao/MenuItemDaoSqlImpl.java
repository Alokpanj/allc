package com.cognizant.truyum.dao;

import java.awt.List;

import com.cognizant.truyum.model.MenuItem;

public abstract class MenuItemDaoSqlImpl implements MenuItemDao {

	@Override
	public List getMenuItemListAdmin() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List getMenuItemListCustomer() {
		// TODO Auto-generated method stub
		return null;
	}

	
	public void editMenuItem(MenuItem menuItem) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public MenuItem getMenuItem(long menuItemId) {
		// TODO Auto-generated method stub
		return null;
	}

}
