package com.cognizant.truyum.dao;

import java.sql.Connection;

public class ConnectionHandler {
	public Connection getConnection(){
		return null;
	}
}
