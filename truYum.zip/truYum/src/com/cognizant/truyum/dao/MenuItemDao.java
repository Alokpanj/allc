package com.cognizant.truyum.dao;

import java.awt.List;

import com.cognizant.truyum.model.MenuItem;

public interface MenuItemDao {
	List getMenuItemListAdmin();
	List getMenuItemListCustomer();
	void modifyMenuItem(MenuItem menuItem);
	MenuItem getMenuItem(long menuItemId);
}
