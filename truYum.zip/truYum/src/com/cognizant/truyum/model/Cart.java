package com.cognizant.truyum.model;

import java.awt.List;

public class Cart {

	private List menuItemList;
	private double total;

	public List getMenuItemList() {
		return menuItemList;
	}

	public void setMenuItemList(List menuItemList) {
		this.menuItemList = menuItemList;
	}

	public double getTotal() {
		return total;
	}

	public void setTotal(double total) {
		this.total = total;
	}
}
