import java.util.*;
public class Main{
    public static void main(String[] args){
        Scanner sc=new Scanner(System.in);
        int id,n; String src,dest; double fare;
        id = sc.nextInt();
        sc.nextLine();
        src = sc.nextLine();
        //sc.nextLine();
        dest = sc.nextLine();
        n = sc.nextInt();
        fare = sc.nextDouble();
        Flight obj = new Flight(id,src,dest,n,fare);
        FlightManagementSystem f = new FlightManagementSystem();
        if(f.addFlight(obj)){
            System.out.println("Flight details added successfully");
        }
        else {
            System.out.println("Addition not done");
        }
        
    }
}