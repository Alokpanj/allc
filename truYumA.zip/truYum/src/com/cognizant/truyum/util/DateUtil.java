package com.cognizant.truyum.util;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Scanner;

public class DateUtil {
	

	public static Date convertToDate(String date)
	{
		Date d=null;
			try{
			SimpleDateFormat sdf=new SimpleDateFormat("dd/MM/yyyy");
			d =(Date)sdf.parse(date);
			}
			
			catch(Exception e)
			{
				System.out.println("Invalid format");
			}
			
		return d;
		
	}
	
	
	

}
