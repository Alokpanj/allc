
package com.cognizant.truyum.dao;

import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import com.cognizant.truyum.model.MenuItem;
import com.cognizant.truyum.util.DateUtil;


public class MenuItemDaoCollectionImpl implements MenuItemDao {

	private static List<MenuItem> menuItemList;
    
	public MenuItemDaoCollectionImpl() {
		if(menuItemList==null)
		{
		menuItemList =new ArrayList<>();
		MenuItem m1=new MenuItem(1l,"Sandwich",99.00f,true,DateUtil.convertToDate("15/03/2017"),"Main Course",true);
		MenuItem m2=new MenuItem(2l,"Burger",129.00f,true,DateUtil.convertToDate("23/12/2017"),"Main Course",false);
		MenuItem m3=new MenuItem(3l,"Pizza",149.00f,true,DateUtil.convertToDate("21/08/2018"),"Main Course",false);
		MenuItem m4=new MenuItem(4l,"French Fries",57.00f,false,DateUtil.convertToDate("02/07/2017"),"Starters",true);
		MenuItem m5=new MenuItem(5l,"Chocolate Brownie",32.00f,true,DateUtil.convertToDate("15/03/2022"),"Dessert",true);
		menuItemList.add(m1);
		menuItemList.add(m2);
		menuItemList.add(m3);
		menuItemList.add(m4);
		menuItemList.add(m5);
		}
		
	}

	@Override
	public java.util.List<MenuItem> getMenuItemListAdmin() {
	
		return  menuItemList;
	}

	
	public java.util.List<MenuItem> getMenuItemListCustomer() {
		
		Date curr_date=new Date();
		List<MenuItem> customerList=new ArrayList<>();
		for(MenuItem m:menuItemList)
		{
			Date d1=m.getDateOfLaunch();
			boolean avail=m.isActive();
			if((d1.compareTo(curr_date)<=0)&&avail)
			{
				customerList.add(m);
			}	
		}
		
		return customerList;
	}
        
	
	
	public void modifyMenuItem(MenuItem menuItem) {
		
		long id=menuItem.getId();
		for(MenuItem m:menuItemList)
		{
			
			if(id==m.getId())
			{
				m.setName("Chilli Paneer");
				m.setPrice(249.00f);
				m.setActive(true);
				m.setCategory("Starters");
				m.setFreeDelivery(false);
			}
		}
		
	}
	public MenuItem getMenuItem(long menuItemId) {
		for(MenuItem m:menuItemList)
		{
			if(m.getId()==menuItemId)
			{
				return m;
			}
		}
		return null;
	  
	}
	
	

}
