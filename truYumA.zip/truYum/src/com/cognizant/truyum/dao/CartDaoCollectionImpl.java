package com.cognizant.truyum.dao;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import com.cognizant.truyum.model.Cart;
import com.cognizant.truyum.model.MenuItem;
import com.cognizant.truyum.util.DateUtil;

public class CartDaoCollectionImpl implements CartDao {

	 static HashMap<Long , Cart> userCarts=new HashMap<>();

	public CartDaoCollectionImpl() 
	{
		if(userCarts==null)
	     {
			userCarts =new HashMap<Long ,Cart>();
	     }
			
			
     }
	
	public void addCartItem(long userId, long menuItemId) {
		
		MenuItemDao menuItemDao=new MenuItemDaoCollectionImpl();
	    List<MenuItem> menuItemList=new ArrayList<>();
		MenuItem m1=menuItemDao.getMenuItem(menuItemId);
		if(userCarts.containsKey(userId))
		{
			List<MenuItem> m2=userCarts.get(userId).getMenuItemList();
			m2.add(m1);
			System.out.println("item added to existing user");
			
		}
		else{
			ArrayList<MenuItem> l1=new ArrayList<>();
			l1.add(m1);
			Cart c=new Cart(l1,0);
			userCarts.put(userId,c);
			System.out.println("item added to new user ");
		    }
	
	
		}
	
	

	public List<MenuItem> getAllCartItems(long userId) throws CartEmptyException {
		
		List<MenuItem> menuItemList=new ArrayList<>();
		menuItemList =userCarts.get(userId).getMenuItemList();
		
		return menuItemList;
		
	}

	
	public void removeCartItem(long userId, long menuItemId) {
		List<MenuItem> menuItemList=new ArrayList<>();
		menuItemList =userCarts.get(userId).getMenuItemList();
        for(MenuItem m:menuItemList)
        {
        	if(m.getId()==menuItemId)
        	{
        		menuItemList.remove(m);
        	}
        }
        //ArrayList<MenuItem> l1=new ArrayList<>();
		//l1.add(m1);
		Cart c=new Cart(menuItemList,0);
		userCarts.put(userId,c);
	}

}
