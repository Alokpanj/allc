package com.cognizant.truyum.dao;

import java.util.List;

import com.cognizant.truyum.model.MenuItem;
import com.cognizant.truyum.util.DateUtil;

public class MenuItemDaoCollectionImplTest {

	public static void main(String args[])
	{
		testGetMenuItemListAdmin();
		testGetMenuItemListCustomer();
		testModifyMenuItem();
		testGetMenuItem();
	}
	
	public static void testGetMenuItemListAdmin()
	{
		MenuItemDao menuItemDao=new MenuItemDaoCollectionImpl();
		List<MenuItem> menulist= menuItemDao.getMenuItemListAdmin();
		for(MenuItem m: menulist)
		{
			System.out.println(m);
		}
		System.out.println();
System.out.println("***********************************************************************************************************************************************");
System.out.println();
	}
	
	public static void testGetMenuItemListCustomer()
	{
		MenuItemDao menuItemDao=new MenuItemDaoCollectionImpl();
		 List<MenuItem> custList=menuItemDao.getMenuItemListCustomer();
		 for(MenuItem m1:custList)
		 {
			 System.out.println(m1);
		 }
			System.out.println();
		    System.out.println("***********************************************************************************************************************************************");
		    System.out.println();
			
	}

	public static void testModifyMenuItem()
	{
		MenuItem m3=new MenuItem(3l,"Pizza",149.00f,true,DateUtil.convertToDate("21/08/2018"),"Main Course",false);
		MenuItemDao menuItemDao=new MenuItemDaoCollectionImpl();
		menuItemDao.modifyMenuItem(m3);
	}
	
	public static void testGetMenuItem()
	{  
		long l=3;
		MenuItemDao menuItemDao=new MenuItemDaoCollectionImpl();
		 MenuItem menuItem=menuItemDao.getMenuItem(l);
		
			 System.out.println(menuItem);
		 
			
	}
}
	

