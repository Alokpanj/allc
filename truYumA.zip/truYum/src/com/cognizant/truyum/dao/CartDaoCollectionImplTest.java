package com.cognizant.truyum.dao;

import java.util.ArrayList;
import java.util.List;

import com.cognizant.truyum.model.MenuItem;

public class CartDaoCollectionImplTest {

	public static void main(String[] args)  throws Exception
	{
		testAddCartItem();
		testGetAllCartItems();
		testRemoveCartItem();
		testGetAllCartItems();
	}
	
	public static void testAddCartItem()
	{
		CartDao ct=new CartDaoCollectionImpl();
				ct.addCartItem(100L, 1L);
				ct.addCartItem(100L, 2L);
				ct.addCartItem(101L, 2L);
	}
	
	public static void testGetAllCartItems() throws CartEmptyException
	{   double sum=0;
		 CartDao cartDao= new CartDaoCollectionImpl();
		 List<MenuItem> menuItemList= cartDao.getAllCartItems(100L);
		 
		 for(MenuItem m1:menuItemList)
		 {
			 System.out.println(m1);
			 sum=sum+m1.getPrice();
		 }
		
			System.out.println("Total price for Added Cart: "+sum);
				
	}
	
	public static void  testRemoveCartItem()throws CartEmptyException
	{
		CartDao cartDao= new CartDaoCollectionImpl();
		cartDao.removeCartItem(100L, 1L);
		//cartDao.getAllCartItems(100L);
	}
}
