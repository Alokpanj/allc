import java.io.File;
import java.util.Scanner;

//import necessary packages

 @SuppressWarnings("unchecked")//Do not delete this line
public class Main
{
	public static void main(String[] args) 
	{
		
		Scanner sc = new Scanner(System.in);
		//FileManager f5  = new FileManager();
		 
		String s ="";
	 boolean b = true;
	 
	 File f1 =  FileManager.createFile();
		while(b){
		System.out.println("Enter Name");
		String s1 = sc.next();
		System.out.println("Enter Phone Number");
		long l1 = sc.nextLong();
		System.out.println("Enter Email");
		String s2 = sc.next();
		System.out.println("Do you want to enter another record(yes/no)");
		 String s3 = sc.next();
		 s=s1+","+l1+","+s2+"\n";
		 FileManager.writeFile(f1, s);
		 if(s3.equalsIgnoreCase("yes")){
			 b=true;
			 continue;
		 }
		 else{
			b = false;
			 
		 
		}
		
	//	f.createFile();
	//	f.writeFile(f1, s);
		
	String[] arr = FileManager.readFile(f1);
	for(String s9: arr){
	System.out.println(s9);
	}
	}
    
}
}