package com.example.springmvcformvalidationexample;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringMvcFormValidationExampleApplicationTests {

	@Test
	void contextLoads() {
	}

}
