package com.example.springmvcformvalidationexample;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringMvcFormValidationExampleApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringMvcFormValidationExampleApplication.class, args);
	}

}
