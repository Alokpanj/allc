import java.io.*;
import java.util.*;
public class FileDemo{
    public static void main(String[] args)
    {
        File f = null;
        BufferedReader br = null;
        FileReader fr = null;
        String s = null;
         String str[] = null;
         int count = 0;
        try{
          
            fr = new  FileReader("log.txt");
            br = new  BufferedReader(fr);
            while((s=br.readLine())!=null){
                 str = s.split(" ");
                for(int i= 0 ;i<str.length;i++){
                    if(str[i].equalsIgnoreCase("knowledge"))
                    count++;
                }
                
                }
        }catch(Exception e){
            e.printStackTrace();
        }
         System.out.println(count);
    }
}
